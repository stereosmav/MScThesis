####### PACKAGES #########

library(ggplot2)
library(ggpubr)
library(tseries)
library(moments)
library(ismev)
library(fExtremes)
library(extremefit)
install.packages("ReIns")
library(ReIns)
#library(evir)

############################## UNIVARIATE EXTREME VALUE THEORY (MANUAL) ###########################

#importing data
returns = read.csv(file = "exch_rate_returns.csv",header = T,sep = ",",dec = ".")
returns = returns[,2:6]

neg_returns = matrix(0,4187,5)
neg_returns = as.data.frame(neg_returns)
neg_returns[,2:5] = -(returns[,2:5])
neg_returns[,1] = returns[,1]
colnames(neg_returns) = colnames(returns)

write.csv(x = neg_returns,file = "exch_rate_neg_returns.csv",col.names = T, row.names = F)

################# EUR/GBP #################### 

#plotting mean resid life plot for EUR/GBP to determine threshold u.
#creating vector of possible thresholds:
u1 = seq(0,max(returns[,2]),0.1)
u2 = seq(0,max(returns[,3]),0.1)
u3 = seq(0,max(returns[,4]),0.1)
u4 = seq(0,max(returns[,5]),0.1)

u5 = seq(0,max(neg_returns[,2]),0.1)
u6 = seq(0,max(neg_returns[,3]),0.1)
u7 = seq(0,max(neg_returns[,4]),0.1)
u8 = seq(0,max(neg_returns[,5]),0.1)

x1 = vector('numeric',length(u1))
x2 = vector('numeric',length(u2))
x3 = vector('numeric',length(u3))
x4 = vector('numeric',length(u4))

x5 = vector('numeric',length(u5))
x6 = vector('numeric',length(u6))
x7 = vector('numeric',length(u7))
x8 = vector('numeric',length(u8))


#mean excess of data for each value of u:

#positive

for (i in 1:length(x1)){
  threshold.exceedances1 = returns$EURGBP[returns$EURGBP>u1[i]]
  x1[i] = mean(threshold.exceedances1-u1[i])
}
for (i in 1:length(x2)){
  threshold.exceedances2 = returns$EURJPY[returns$EURJPY>u2[i]]
  x2[i] = mean(threshold.exceedances2-u2[i])
}
for (i in 1:length(x3)){
  threshold.exceedances3 = returns$EURTRY[returns$EURTRY>u3[i]]
  x3[i] = mean(threshold.exceedances3-u3[i])
}
for (i in 1:length(x4)){
  threshold.exceedances4 = returns$EURUSD[returns$EURUSD>u4[i]]
  x4[i] = mean(threshold.exceedances4-u4[i])
}

#negative

for (i in 1:length(x5)){
  threshold.exceedances5 = neg_returns$EURGBP[neg_returns$EURGBP>u5[i]]
  x5[i] = mean(threshold.exceedances5-u5[i])
}
for (i in 1:length(x6)){
  threshold.exceedances6 = neg_returns$EURJPY[neg_returns$EURJPY>u6[i]]
  x6[i] = mean(threshold.exceedances6-u6[i])
}
for (i in 1:length(x7)){
  threshold.exceedances7 = neg_returns$EURTRY[neg_returns$EURTRY>u7[i]]
  x7[i] = mean(threshold.exceedances7-u7[i])
}
for (i in 1:length(x8)){
  threshold.exceedances8 = neg_returns$EURUSD[neg_returns$EURUSD>u8[i]]
  x8[i] = mean(threshold.exceedances8-u8[i])
}


#mrl plot

#positive:

plot(x1~u1,type = "l",main = "i) Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,6,0.2))
abline(v=(1.1), col="blue", lty=3, lwd=0.5)
#u1=1.1
plot(x2~u2,type = "l",main = "Mean Residual Life Plot: EUR/JPY - righ tail",xlab = "threshold u",
     ylab = "mean excess",xaxt="none", frame.plot=F)
axis(1, seq(0,8,0.2))
abline(v=(1.4), col="blue", lty=3, lwd=0.5)
#u2 =1.4 or 1.7
plot(x3~u3,type = "l",main = "Mean Residual Life Plot: EUR/TRY - right tail",xlab = "threshold u",
     ylab = "mean excess",xaxt="none",xlim = c(0,8), frame.plot=F)
axis(1, seq(0,8,0.2))
abline(v=(1.7), col="blue", lty=3, lwd=0.5)
#u3=1.7 or 2.25
plot(x4~u4,type = "l",main = "Mean Residual Life Plot: EUR/USD - right tail",xlab = "threshold u",
     ylab = "mean excess",xaxt="none",xlim = c(0,12), frame.plot =F)
axis(1, seq(0,12,0.5))
abline(v=(1), col="blue", lty=3, lwd=0.5)
#u4 = 1

#negative:

plot(x5~u5,type = "l",main = "Mean Residual Life Plot: EUR/GBP - left tail",xlab = "threshold u", ylab = "mean excess", xaxt="none",frame.plot=F)
axis(1, seq(0,4,0.2))
abline(v=(0.8), col="blue", lty=3, lwd=0.5)
#u5=0.8
plot(x6~u6,type = "l",main = "Mean Residual Life Plot: EUR/JPY - left tail",xlab = "threshold u", ylab = "mean excess",xaxt="none", frame.plot =F)
axis(1, seq(0,6,0.2))
abline(v=(1), col="blue", lty=3, lwd=0.5)
#u6 = 1
plot(x7~u7,type = "l",main = "Mean Residual Life Plot: EUR/TRY - left tail",xlab = "threshold u", xlim = c(0,8),
     ylab = "mean excess",xaxt="none", frame.plot=F)
axis(1, seq(0,8,0.2))
abline(v=(1.25), col="blue", lty=3, lwd=0.5)
#u7=1.25
plot(x8~u8,type = "l",main = "Mean Residual Life Plot: EUR/USD - left tail",xlab = "threshold u", ylab = "mean excess",xaxt="none", frame.plot=F)
axis(1, seq(0,14,0.5))
abline(v=(1.2), col="blue", lty=3, lwd=0.5)
#u8 = 1.2

#better to choose as low a threshold as possible


#create matrix for thresholds
u = matrix(0,nrow = 1,ncol = 8)
colnames(x = u) = c('EUR/GBP','EUR/JPY','EUR/TRY','EUR/USD','EUR/GBP','EUR/JPY','EUR/TRY','EUR/USD')
u[] = c(1.1,1.4,1.7,1,0.8,1,1.25,1.2)

exceedances1 = returns$EURGBP[returns$EURGBP>u[1]]
y1 = exceedances1 - u[1]
k1 = length(y1)

exceedances2 = returns$EURJPY[returns$EURJPY>u[2]]
y2 = exceedances2 - u[2]
k2 = length(y2)

exceedances3 = returns$EURTRY[returns$EURTRY>u[3]]
y3 = exceedances3 - u[3]
k3 = length(y3)

exceedances4 = returns$EURUSD[returns$EURUSD>u[4]]
y4 = exceedances4 - u[4]
k4 = length(y4)

#negative:
exceedances5 = neg_returns$EURGBP[neg_returns$EURGBP>u[5]]
y5 = exceedances5 - u[5]
k5 = length(y5)

exceedances6 = neg_returns$EURJPY[neg_returns$EURJPY>u[6]]
y6 = exceedances6 - u[6]
k6 = length(y6)

exceedances7 = neg_returns$EURTRY[neg_returns$EURTRY>u[7]]
y7 = exceedances7 - u[7]
k7 = length(y7)

exceedances8 = neg_returns$EURUSD[neg_returns$EURUSD>u[8]]
y8 = exceedances8 - u[8]
k8 = length(y8)

#we study the length size k of the exceedances and adjust threshold u accordingly
#when gamma(extreme index) from hill estimator becomes stable.

Y1 = y1[order(y1,decreasing = T)]
Y2 = y2[order(y2,decreasing = T)]
Y3 = y3[order(y3,decreasing = T)]
Y4 = y4[order(y4,decreasing = T)]
Y5 = y5[order(y5,decreasing = T)]
Y6 = y6[order(y6,decreasing = T)]
Y7 = y7[order(y7,decreasing = T)]
Y8 = y8[order(y8,decreasing = T)] #order the excesses

#using hill estimator for the graphs of extr index gamma against k:
#choosing k:
par(mfrow = c(1,1))
gamma1 = matrix(0,1,k1)
M1 = matrix(0,1,k1)
gammaM1 = matrix(0,1,k1)
for (k in 1:k1){
  gamma1[k] = (sum(log(Y1[1:k]/Y1[k]))/k)^(-1)
  M1[k] = (sum(log(Y1[1:k]/Y1[k]))^2)/k
  gammaM1[k] = gamma1[k] + 1 - (1/2) * (1 - ((gamma1[k]^2)/M1[k]))
}
gammaM1
plot((2:k1),gamma1[2:k1],type = "l")
lines(gammaM1[2:k1],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##2

gamma2 = matrix(0,1,k2)
M2 = matrix(0,1,k2)
gammaM2 = matrix(0,1,k2)
for (k in 1:k2){
  gamma2[k] = (sum(log(Y2[1:k]/Y2[k]))/k)^(-1)
  M2[k] = (sum(log(Y2[1:k]/Y2[k]))^2)/k
  gammaM2[k] = gamma2[k] + 1 - (1/2) * (1 - ((gamma2[k]^2)/M2[k]))
}
plot((1:k2),gamma2,type = "l")
lines(gammaM2[2:k2],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##3

gamma3 = matrix(0,1,k3)
M3 = matrix(0,1,k3)
gammaM3 = matrix(0,1,k3)
for (k in 1:k3){
  gamma3[k] = (sum(log(Y3[1:k]/Y3[k]))/k)^(-1)
  M3[k] = (sum(log(Y3[1:k]/Y3[k]))^2)/k
  gammaM3[k] = gamma3[k] + 1 - (1/2) * (1 - ((gamma3[k]^2)/M3[k]))^(-1)
}
plot((1:k3),gamma3,type = "l")
lines(gammaM3[2:k3],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##4
gamma4 = matrix(0,1,k4)
M4 = matrix(0,1,k4)
gammaM4 = matrix(0,1,k4)
for (k in 1:k4){
  gamma4[k] = (sum(log(Y4[1:k]/Y4[k]))/k)^(-1)
  M4[k] = (sum(log(Y4[1:k]/Y4[k]))^2)/k
  gammaM4[k] = gamma4[k] + 1 - (1/2) * (1 - ((gamma4[k]^2)/M4[k]))^(-1)
}
plot((1:k4),gamma4,type = "l")
lines(gammaM4[2:k4],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##5

gamma5 = matrix(0,1,k5)
M5 = matrix(0,1,k5)
gammaM5 = matrix(0,1,k5)
for (k in 1:k5){
  gamma5[k] = (sum(log(Y5[1:k]/Y5[k]))/k)^(-1)
  M5[k] = (sum(log(Y5[1:k]/Y5[k]))^2)/k
  gammaM5[k] = gamma5[k] + 1 - (1/2) * (1 - ((gamma5[k]^2)/M5[k]))^(-1)
}
plot((1:k5),gamma5,type = "l")
lines(gammaM5[2:k5],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##6
gamma6 = matrix(0,1,k6)
M6 = matrix(0,1,k6)
gammaM6 = matrix(0,1,k6)
for (k in 1:k6){
  gamma6[k] = (sum(log(Y6[1:k]/Y6[k]))/k)^(-1)
  M6[k] = (sum(log(Y6[1:k]/Y6[k]))^2)/k
  gammaM6[k] = gamma6[k] + 1 - (1/2) * (1 - ((gamma6[k]^2)/M6[k]))^(-1)
}
plot((1:k6),gamma6,type = "l")
lines(gammaM6[2:k6],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##7
gamma7 = matrix(0,1,k7)
M7 = matrix(0,1,k7)
gammaM7 = matrix(0,1,k7)
for (k in 1:k7){
  gamma7[k] = (sum(log(Y7[1:k]/Y7[k]))/k)^(-1)
  M7[k] = (sum(log(Y7[1:k]/Y7[k]))^2)/k
  gammaM7[k] = gamma7[k] + 1 - (1/2) * (1 - ((gamma7[k]^2)/M7[k]))^(-1)
}
plot((1:k7),gamma7,type = "l")
lines(gammaM7[2:k7],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##8
gamma8 = matrix(0,1,k8)
M8 = matrix(0,1,k8)
gammaM8 = matrix(0,1,k8)
for (k in 1:k8){
  gamma8[k] = (sum(log(Y8[1:k]/Y8[k]))/k)^(-1)
  M8[k] = (sum(log(Y8[1:k]/Y8[k]))^2)/k
  gammaM8[k] = gamma8[k] + 1 - (1/2) * (1 - ((gamma8[k]^2)/M8[k]))^(-1)
}
plot((1:k8),gamma8,type = "l")
lines(gammaM8[2:k8],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")


#fitting y excesses to GPD through MLE:
#EUR/GBP positive
theta_ini = c(sd(y1),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y1)
results

sigma1 = results$estimate[1]
ksi1 = results$estimate[2]

#EUR/JPY pos
theta_ini = c(sd(y2),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y2)
results

sigma2 = results$estimate[1]
ksi2 = results$estimate[2]

#EUR/TRY pos
theta_ini = c(sd(y3),0.1)

source("llik_GPD.R")
options(scipen=999)


#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y3)
results

sigma3 = results$estimate[1]
ksi3 = results$estimate[2]

#EUR/USD pos:
theta_ini = c(sd(y4),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y4)
results

sigma4 = results$estimate[1]
ksi4 = results$estimate[2]

#EUR/GBP neg:
theta_ini = c(sd(y5),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y5)
results

sigma5 = results$estimate[1]
ksi5 = results$estimate[2]

#EUR/JPY neg:
theta_ini = c(sd(y6),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y6)
results

sigma6 = results$estimate[1]
ksi6 = results$estimate[2]

#EUR/TRY neg
theta_ini = c(sd(y7),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y7)
results

sigma7 = results$estimate[1]
ksi7 = results$estimate[2]

#EUR/USD neg
theta_ini = c(sd(y8),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y8)
results

sigma8 = results$estimate[1]
ksi8 = results$estimate[2]

#organising results:
sigmas = c(sigma1,sigma2, sigma3, sigma4, sigma5, sigma6, sigma7, sigma8)
ksis = c(ksi1, ksi2, ksi3, ksi4, ksi5, ksi6, ksi7, ksi8)

####################################HILL ESTIMATOR GRAPHS FOR THRESHOLD CHOICE #################
par(mfrow = c(2,2))
hillPlot(x = Y1,ci = 0.95)
abline(v=(35), col="red", lty=3, lwd=0.5)
legend("topright", c("EUR/GBP - right tail", "u = 1.1"))
#u1 = 1.1

hillPlot(x = y2,ci = 0.95)
abline(v=(35), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/JPY - right tail", "u = 1.6"))
#u2 = 2

hillPlot(x = y3,ci = 0.95)
abline(v=(55), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/TRY - right tail", "u = 2"))

hillPlot(x = y4,ci = 0.95)
abline(v=(80), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/USD - right tail", "u = 0.8"))

hillPlot(x = y5,ci = 0.95)
abline(v=(30), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/GBP - left tail", "u = 0.75"))

hillPlot(x = y6,ci = 0.95)
abline(v=(42), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/JPY - left tail", "u = 1.25"))

hillPlot(x = y7,ci = 0.95)
abline(v=(50), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/TRY - left tail", "u = 1.15"))

hillPlot(x = y8,ci = 0.95)
abline(v=(34), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/USD - left tail", "u = 1.45"))

#################################### Hill estimator ##########################################
ksih = matrix(0,1,8)

hillest = function(sortx,k){    #computing block for the moment estimator, cf. formula (3.5.2) in  deHaan & Ferreira (2006)
  X=sort(sortx,decreasing=TRUE);
  result=numeric(length(k));
  for(i in 1:length(k)){
    Xdiff=(log(X[1:k[i]])-log(X[k[i]+1]));
    result[i]=mean(Xdiff);
  }
  return(result);
}

hill1 = hillest(y1,1:k1); plot(hill1[1:91], type = "l")
abline(0.5,0,col = "blue") #ksih1 = 0.5
hill2 = hillest(y2,1:k2); plot(hill2[1:97], type = "l")
abline(0.5,0,col = "blue") #ksih2 = 0.5
hill3 = hillest(y3,1:k3); plot(hill3[1:170], type = "l")
abline(0.5,0,col = "blue") #ksih1 = 0.5
hill4 = hillest(y4,1:k4); plot(hill4[1:169], type = "l")
abline(0.65,0,col = "blue") #ksih1 = 0.65
hill5 = hillest(y5,1:k5); plot(hill5[1:211], type = "l")
abline(0.3,0,col = "blue") #ksih5 = 0.3

#hill estimator for ksi:
Y1
ksih[1] = (sum(log(Y1/Y1[k1]))/k1)^(-1)
ksih[1]
ksis[1]

ksih[2] = (sum(log(Y2/Y2[k2]))/k2)^(-1)
ksih[2]
ksis[2]

ksih[3] = (sum(log(Y3/Y3[k3]))/k3)^(-1)
ksih[3]
ksis[3]

ksih[4] = (sum(log(Y4/Y4[k4]))/k4)^(-1)
ksih[4]
ksis[4]

ksih[5] = (sum(log(Y5/Y5[k5]))/k5)^(-1)
ksih[5]
ksis[5]

ksih[6] = (sum(log(Y6/Y6[k6]))/k6)^(-1)
ksih[6]
ksis[6]

ksih[7] = (sum(log(Y7/Y7[k7]))/k7)^(-1)
ksih[7]
ksis[7]

ksih[8] = (sum(log(Y8/Y8[k8]))/k8)^(-1)
ksih[8]
ksis[8]

########Moment estimator:
par(mfrow = c(1,1))

Mq=function(sortx,k,q){    #computing block for the moment estimator, cf. formula (3.5.2) in  deHaan & Ferreira (2006)
  X=sort(sortx,decreasing=TRUE);
  result=numeric(length(k));
  for(i in 1:length(k)){
    Xdiff=(log(X[1:k[i]])-log(X[k[i]+1]))^q;
    result[i]=mean(Xdiff);
  }
  return(result);
}


g_mom=function(sortx,k)
{
  X=sort(sortx,decreasing=TRUE);
  result=numeric(length(k));
  M1=Mq(sortx,k,1);
  M2=Mq(sortx,k,2);  
  result=M1+1-0.5*M2/(M2-M1^2);
  return(result);
}

#simulation example
df=3;
xt=rt(5000,df);
k=10:1000;
gamma_mom= g_mom(xt,k)
gamma_mom
plot(gamma_mom, type ="l")

#
par(mfrow = c(2,2))

ksiM = matrix(0,1,8)

M1 = g_mom(y1,1:k1); plot(M1[2:91], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/GBP right tail")
M1
abline(0.35,0,col = "blue") #ksim1 = 0.35
ksiM[1] = mean(M1[4:91]) ; ksiM[1]
ksis[1]

#moment function to make sure results are the same 
M1i = Moment(data = y1)
M1i
plot(M1i$gamma[2:91], type = "l")

M2 = g_mom(y2,1:k2); plot(M2[2:104], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/JPY right tail")
M2
abline(0.35,0,col = "blue") #ksim2 = 0.35
ksiM[2] = mean(M2[4:85]) ; ksiM[2]
ksis[2]

M3 = g_mom(y3,1:k3); plot(M3[2:176], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/TRY right tail")
M3
abline(0.5,0,col = "blue") #ksim3 = 0.5
ksiM[3] = mean(M3[5:95]) ; ksiM[3]
ksis[3]

M4 = g_mom(y4,1:k4); plot(M4[2:181], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/USD right tail")
M4
abline(0.6,0,col = "blue") #ksim4 = 0.6
ksiM[4] = mean(M4[25:100]) ; ksiM[4]
ksis[4]

M5 = g_mom(y5,1:k5); plot(M5[4:215], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/GBP left tail")
M5
abline(0.2,0,col = "blue") #ksim5 = 0.2
ksiM[5] = mean(M5[35:197]) ; ksiM[5]
ksis[5]

M6 = g_mom(y6,1:k6); plot(M6[7:276], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/JPY left tail")
M6
abline(0.20,0,col = "blue") #ksim6 = 0.2
ksiM[6] = mean(M6[49:121]) ; ksiM[6]
ksis[6]

M7 = g_mom(y7,1:k7); plot(M7[2:267], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/TRY left tail")
M7
abline(0.3,0,col = "blue") #ksim7 = 0.3
ksiM[7] = mean(M7[5:192]) ; ksiM[7]
ksis[7]


M8 = g_mom(y8,1:k8); plot(M8[7:119], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/USD left tail")
M8
abline(0.8,0,col = "blue") #ksim8 = 0.8
ksiM[8] = mean(M8[11:110]) ; ksiM[8]
ksis[8]
#we choose the first stable area!!

##################

M = matrix(0,1,8)
ksim = matrix(0,1,8)
ksih

#
M[1] = (sum(log(Y1/Y1[k1]))^2)/k1
ksim[1] = ksih[1] + 1 - (1/2) * (1 - ((ksih[1]^2)/M[1]))^(-1)
ksim[1]

M[2] = (sum(log(Y2/Y2[k2]))^2)/k2
ksim[2] = ksih[2] + 1 - (1/2) * (1 - ((ksih[2]^2)/M[2]))^(-1)
ksim[2]

M[3] = (sum(log(Y3/Y3[k3]))^2)/k3
ksim[3] = ksih[3] + 1 - (1/2) * (1 - ((ksih[3]^2)/M[3]))^(-1)
ksim[3]

M[4] = (sum(log(Y4/Y4[k4]))^2)/k4
ksim[4] = ksih[4] + 1 - (1/2) * (1 - ((ksih[4]^2)/M[4]))^(-1)
ksim[4]

M[5] = (sum(log(Y5/Y5[k5]))^2)/k5
ksim[5] = ksih[5] + 1 - (1/2) * (1 - ((ksih[5]^2)/M[5]))^(-1)
ksim[5]

M[6] = (sum(log(Y6/Y6[k6]))^2)/k6
ksim[6] = ksih[6] + 1 - (1/2) * (1 - ((ksih[6]^2)/M[6]))^(-1)
ksim[6]

M[7] = (sum(log(Y7/Y7[k7]))^2)/k7
ksim[7] = ksih[7] + 1 - (1/2) * (1 - ((ksih[7]^2)/M[7]))^(-1)
ksim[7]

M[8] = (sum(log(Y8/Y8[k8]))^2)/k8
ksim[8] = ksih[8] + 1 - (1/2) * (1 - ((ksih[8]^2)/M[8]))^(-1)
ksim[8]

#threshold exceedance rate:
z = matrix(0,1,8)
n = length(returns[,2])

z[1] = k1/n
z[2] = k2/n
z[3] = k3/n
z[4] = k4/n
z[5] = k5/n
z[6] = k6/n
z[7] = k7/n 
z[8] = k8/n

########calculating return levels.######(NOT NECESSARY)
#Furthermore, the return level plot is simply a graph
#of value-at-risk against risk, on a convenient scale
N = seq(1,1000)
m = N*250
x = matrix(0,1000,8)

for (i in 1:8){
  for (t in 1:length(N)){
    x[t,i] = u[i] + (sigmas[i]/ksis[i]) * ((m[t] * z[i])^ksis[i] - 1)
  }
}
m
#return level of 10 years for all rates pos and neg:
for (i in 1:8){
  print(x[10,i])
}
#return level of 25 years for all rates pos and neg:
for (i in 1:8){
  print(x[25,i])
}
#return level of 50 years for all rates pos and neg:
for (i in 1:8){
  print(x[50,i])
}
#return level of 50 years for all rates pos and neg:
for (i in 1:8){
  print(x[100,i])
}


#return level plot:#########not necessary
X = log(x[])
M = log(m)
par(mfrow = c(2,2))

#right tail:
for (i in 1:4){
  plot(x[,i]~N,type = "l",main = "Return level plot,", ylab = "Return level", xlab = "Return period")
}

#left tail:
for (i in 5:8){
  plot(x[,i]~N,type = "l",main = "Return level plot,", ylab = "Return level", xlab = "Return period")
}

######################### GRAPHS FOR MODEL CHECKING ###############

fitgdp = gpd.fit(xdat = returns$EURGBP,threshold = u[1])
gpd.diag(fitgdp)
dgpd(x = y1,xi = ksis[1],beta = sigmas[1])
gpd.prof(fitgdp,m = 100,xlow = 3.5,xup = 60,npy = 260)



#################################### MANUAL TRY FOR GRAPHS ############
#manually:


#####prob plot:

y1 = y1[order(y1)]
y2 = y2[order(y2)]
y3 = y3[order(y3)]
y4 = y4[order(y4)]
y5 = y5[order(y5)]
y6 = y6[order(y6)]
y7 = y7[order(y7)]
y8 = y8[order(y8)] 

#estimation of model:

H1 = 1 - (1 + (ksis[1]*y1)/sigmas[1])^(-1/ksis[1])
H2 = 1 - (1 + (ksis[2]*y2)/sigmas[2])^(-1/ksis[2])
H3 = 1 - (1 + (ksis[3]*y3)/sigmas[3])^(-1/ksis[3])
H4 = 1 - (1 + (ksis[4]*y4)/sigmas[4])^(-1/ksis[4])
H5 = 1 - (1 + (ksis[5]*y5)/sigmas[5])^(-1/ksis[5])
H6 = 1 - (1 + (ksis[6]*y6)/sigmas[6])^(-1/ksis[6])
H7 = 1 - (1 + (ksis[7]*y7)/sigmas[7])^(-1/ksis[7])
H8 = 1 - (1 + (ksis[8]*y8)/sigmas[8])^(-1/ksis[8])
length(H1)
y1
#plots:


#EUR/GBP pos:
i1 = seq(1,k1,1)
empirical1 = i1/(k1+1)
plot(x = empirical1,y = H1, main = "Probability Plot: EUR/GBP - right tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1,lwd =2)

#EUR/JPY pos:
i2 = seq(1,k2,1)
empirical2 = i2/(k2+1)
plot(x = empirical2,y = H2, main = "Probability Plot: EUR/JPY - right tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1, lwd = 2)

#EUR/TRY pos:
i3 = seq(1,k3,1)
empirical3 = i3/(k3+1)
plot(x = empirical3,y = H3, main = "Probability Plot: EUR/TRY - right tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1,lwd =2)

#EUR/USD pos:
i4 = seq(1,k4,1)
empirical4 = i4/(k4+1)
plot(x = empirical4,y = H4, main = "Probability Plot: EUR/USD - right tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1,lwd =2)

#EUR/GBP neg :
i5 = seq(1,k5,1)
empirical5 = i5/(k5+1)
plot(x = empirical5,y = H5, main = "Probability Plot: EUR/GBP - left tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1,lwd=2)

#EUR/JPY neg :
i6 = seq(1,k6,1)
empirical6 = i6/(k6+1)
plot(x = empirical6,y = H6, main = "Probability Plot: EUR/JPY - left tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F,col="red")
abline(0,1,lwd=2)

#EUR/TRY neg :
i7 = seq(1,k7,1)
empirical7 = i7/(k7+1)
plot(x = empirical7,y = H7, main = "Probability Plot: EUR/TRY - left tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1,lwd = 2)

#EUR/USD neg :
i8 = seq(1,k8,1)
empirical8 = i8/(k8+1)
plot(x = empirical8,y = H8, main = "Probability Plot: EUR/USD - left tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1,lwd=2)

#quantile plot:
#use of decreasing order


#EUR/GBP pos
h1 = u[1] + (sigmas[1]/ksis[1]) * (empirical1^(-ksis[1])-1)
plot(h1~Y1, main = "Quantile Plot: EUR/GBP - right tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot1 = lm(h1~Y1)
abline(quantplot1, lwd = 2)

#EUR/JPY pos
h2 = u[2] + (sigmas[2]/ksis[2]) * (empirical2^(-ksis[2])-1)
plot(h2~Y2, main = "Quantile Plot: EUR/JPY - right tail", ylab = "Empirical", 
     xlab = "Model", frame.plot = F, col = "blue")
quantplot2 = lm(h2~Y2)
abline(quantplot2, lwd =2)

#EUR/TRY pos
h3 = u[3] + (sigmas[3]/ksis[3]) * (empirical3^(-ksis[3])-1)
plot(h3~Y3, main = "Quantile Plot: EUR/TRY - right tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot3 = lm(h3~Y3)
abline(quantplot3, lwd = 2)

#EUR/USD pos
h4 = u[4] + (sigmas[4]/ksis[4]) * (empirical4^(-ksis[4])-1)
plot(h4~Y4, main = "Quantile Plot: EUR/USD - right tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot4 = lm(h4~Y4)
abline(quantplot4, lwd = 2)

#EUR/GBP neg:
h5 = u[5] + (sigmas[5]/ksis[5]) * (empirical5^(-ksis[5])-1)
plot(h5~Y5, main = "Quantile Plot: EUR/GBP - left tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot5 = lm(h5~Y5)
abline(quantplot5, lwd =2)

#EUR/JPY neg:
h6 = u[6] + (sigmas[6]/ksis[6]) * (empirical6^(-ksis[6])-1)
plot(h6~Y6, main = "Quantile Plot: EUR/JPY - left tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot6 = lm(h6~Y6)
abline(quantplot6, lwd = 2)

#EUR/TRY neg:
h7 = u[7] + (sigmas[7]/ksis[7]) * (empirical7^(-ksis[7])-1)
plot(h7~Y7, main = "Quantile Plot: EUR/TRY - left tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot7 = lm(h7~Y7)
abline(quantplot7, lwd =2)

#EUR/USD neg:
h8 = u[8] + (sigmas[8]/ksis[8]) * (empirical8^(-ksis[8])-1)
plot(h8~Y8, main = "Quantile Plot: EUR/USD - left tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot8 = lm(h8~Y8)
abline(quantplot8, lwd =2)

######################## density plot ########################################
par(mfrow = c(2,2))

hist(y1, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y1), max(y1), length.out = 20),
     main = "Histogram: EUR/GBP - right tail")
lines(y1,dgpd(y1,xi = ksis[1]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()

hist(y2, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y2), max(y2), length.out = 20),
     main = "Histogram: EUR/JPY - right tail")
lines(y2,dgpd(y2,xi = ksis[2]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()


hist(y3, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y3), max(y3), length.out = 20),
     main = "Histogram: EUR/TRY - right tail")
lines(y3,dgpd(y3,xi = ksis[3]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()

hist(y4, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y4), max(y4), length.out = 20),
     main = "Histogram: EUR/USD - right tail")
lines(y4,dgpd(y4,xi = ksis[4]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()

hist(y5, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y5), max(y5), length.out = 20),
     main = "Histogram: EUR/GBP - left tail")
lines(y5,dgpd(y5,xi = ksis[5]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()


hist(y6, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y6), max(y6), length.out = 20),
     main = "Histogram: EUR/JPY - left tail")
lines(y6,dgpd(y6,xi = ksis[6]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()


hist(y7, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y7), max(y7), length.out = 20),
     main = "Histogram: EUR/TRY - left tail")
lines(y7,dgpd(y7,xi = ksis[7]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()


hist(y8, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y8), max(y8), length.out = 20),
     main = "Histogram: EUR/USD - left tail")
lines(y8,dgpd(y8,xi = ksis[8]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()

################################# VaR CALCULATION #####################

#vector of VaR probabilities
p =c(0.05,0.025,0.01,0.005,0.001)
Value.at.risk = matrix(0,5,8)
K = c(k1,k2,k3,k4,k5,k6,k7,k8)

#VaR for pos and neg returns
for (i in 1:8){
  for (t in 1:5){
    Value.at.risk[t,i] = u[i] + (sigmas[i]/ksis[i]) * (((p[t])*(length(returns[,2])/K[i]))^(-ksis[i]) - 1) 
  }
}  
Value.at.risk
#create profile likelihood for confidence interval of VaR.

#EXPECTED SHORTFALL CALCULATION:

ES = matrix(0,5,8)
for (i in 1:8){
  for (t in 1:5){
    ES[t,i] = (Value.at.risk[t,i]/(1 - ksis[i])) + ((sigmas[i] - ksis[i] * u[i])/(1 - ksis[i])) 
  }
}
ES


########################### Data simulation to check results ######################
#data simulation
data = rt(n = 4187,df = 3,)

#threshold creation
ud = seq(0,max(data),0.1)
xd = vector('numeric',length(ud))

for (i in 1:length(xd)){
  threshold.exceedancesd = data[data>ud[i]]
  xd[i] = mean(threshold.exceedancesd-ud[i])
}

#mean resid life plot for threshold selection
par(mfrow = c(1,1))
plot(xd~ud,type = "l",main = "i) Mean Residual Life Plot: Simulated Data", ylab = "mean excess",xaxt = "none")
axis(1, seq(0,20,1))
#ud = 2.1

ud=1

#creating excesses and length kd
exceedancesd = data[data>ud]
yd = exceedancesd - ud
kd = length(yd)

#decreasing ordering
Yd = yd[order(yd,decreasing = T)]

#hill estimator to different k's
par(mfrow = c(1,1))
gammad = matrix(0,1,kd)
Md = matrix(0,1,kd)
gammaMd = matrix(0,1,kd)
for (k in 1:kd){
  gammad[k] = (sum(log(Yd[1:k]/Y1[k]))/k)^(-1)
  Md[k] = (sum(log(Yd[1:k]/Yd[k]))^2)/k
  gammaMd[k] = gammad[k] + 1 - (1/2) * (1 - ((gammad[k]^2)/Md[k]))
}
plot((1:kd),gammad[1:kd],type = "l" )
lines(gammaMd[1:kd],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")
#stable around 0.45

#fitting y excesses to GPD through MLE:
theta_ini = c(sd(yd),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = yd)
results

sigmad = results$estimate[1]
ksid = results$estimate[2]

#hill estimator:
ksihd = (sum(log(Yd/Yd[kd]))/kd)^(-1)
ksihd

Md = (sum(log(Yd/Yd[kd]))^2)/kd
ksimd = ksihd + 1 - (1/2) * (1 - ((ksihd^2)/Md))^(-1)
ksimd

zd = kd/length(data)

#value at risk:
VaRd = matrix(0,5,1)
for (t in 1:5){
  VaRd[t] = ud + (sigmad/ksid) * (((p[t])*(length(data)/kd))^(-ksid) - 1) 
}
VaRd

ESd = matrix(0,5,1)
for (t in 1:5){
  ESd[t] = (VaRd[t]/(1 - ksid)) + ((sigmad - ksid * ud)/(1 - ksid)) 
}

ESd
