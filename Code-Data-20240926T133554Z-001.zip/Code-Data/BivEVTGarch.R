######## PACKAGES ###########

library(ggplot2)
library(ggpubr)
library(tseries)
library(moments)
library(forecast)
library(rugarch)
library(MTS)
library(evd)
library(POT)
library(fExtremes)
library(extRemes)

################## IMPORTING DATA ###################

returns = read.csv(file = "exch_rate_returns.csv",header = T,sep = ",",dec = ".")
returns = returns[,2:6]

neg_returns = read.csv(file = "exch_rate_neg_returns.csv",header = T,sep = ",",dec = ".")

#################### Estimating biv. EVT for 3 subperiods ###############################

#subperiods for pos returns:
retsub1 = returns[1:1395,] #2005-01-03 - 2010-06-15
retsub2 = returns[1396:2791,]#2010-06-16 - 2015-10-26
retsub3 = returns[2792:4187,]#2015-10-27 - 2021-04-02

#subperiods for neg returns:
negretsub1 = neg_returns[1:1395,]#2005-01-03 - 2010-06-15
negretsub2 = neg_returns[1396:2791,]#2010-06-16 - 2015-10-26 
negretsub3 = neg_returns[2792:4187,]#2015-10-27 - 2021-04-02

##################### EXAMINING WHICH ARMA MODEL IS MOST APPROPRIATE FOR RETURNS ###################

acf(retsub1[,2]); acf(retsub1[,3]); acf(retsub1[,4]); acf(retsub1[,5])
acf(retsub2[,2]); acf(retsub2[,3]); acf(retsub2[,4]); acf(retsub2[,5])
acf(retsub3[,2]); acf(retsub3[,3]); acf(retsub3[,4]); acf(retsub3[,5])

pacf(x = retsub1[,2]); pacf(x = retsub1[,3]); pacf(x = retsub1[,4]); pacf(x = retsub1[,5])
pacf(x = retsub2[,2]); pacf(x = retsub2[,3]); pacf(x = retsub2[,4]); pacf(x = retsub2[,5])
pacf(x = retsub3[,2]); pacf(x = retsub3[,3]); pacf(x = retsub3[,4]); pacf(x = retsub3[,5])

################### SUBPERIOD 1 ###################

#The p,d, and q are then chosen by minimizing the AICc. The algorithm uses 
#a stepwise search to traverse the model space to select the best model with smallest AICc.
auto.arima(y = retsub1[,2],trace = T) #(2,0,2)m=0
auto.arima(y = retsub1[,3],trace = T) #(2,0,2)m=0
auto.arima(y = retsub1[,4],trace = T) #(0,0,1)m=0
auto.arima(y = retsub1[,5],trace = T) #(0,0,1)m=0

#same results for neg returns

################# SUBPERIOD 2 #####################

auto.arima(y = retsub2[,2],trace = T) #(0,0,0)m=0
auto.arima(y = retsub2[,3],trace = T) #(0,0,1)m=0
auto.arima(y = retsub2[,4],trace = T) #(0,0,0)m=0
auto.arima(y = retsub2[,5],trace = T) #(0,0,0)m=0

################ SUBPERIOD 3 ####################

auto.arima(y = retsub3[,2],trace = T) #(0,0,0)m=0
auto.arima(y = retsub3[,3],trace = T) #(0,0,0)m=0
auto.arima(y = retsub3[,4],trace = T) #(2,0,3)m NOT 0
auto.arima(y = retsub3[,5],trace = T) #(0,0,0)m=0

##################### fitting arma model & determining whether heteroskedasticity exists #############################

################# SUBPERIOD 1 #####################

#1 GBP
armodel1i<-arima(retsub1[,2], order = c(2,0,2),include.mean = FALSE); summary(armodel1i)
residuals1i<-residuals(armodel1i)
#arch test
#taking standardized residuals
archTest(residuals1i)#Ljung-Box statistics (Q)
#p-value 0 so null hypothesis rejected-> heteroskedasticity exists in the residuals GARCH model can be used.

#2 JPY
armodel2i<-arima(retsub1[,3], order = c(2,0,2),include.mean = FALSE); summary(armodel2i)
residuals2i<-residuals(armodel2i)
#arch test
#taking standardized residuals
archTest(residuals2i)#Ljung-Box statistics (Q)
#significant p-val so heteroskedasticity

#3 TRY
armodel3i<-arima(retsub1[,4], order = c(0,0,1),include.mean = FALSE); summary(armodel3i)
residuals3i<-residuals(armodel3i)
#arch test
archTest(residuals3i)#Ljung-Box statistics (Q)
#heteroskedasticity

#4 USD
armodel4i<-arima(retsub1[,5], order = c(0,0,1),include.mean = FALSE); summary(armodel4i)
residuals4i<-residuals(armodel4i)
#arch test
archTest(residuals4i)#Ljung-Box statistics (Q)
#heteroskedasticity

############### SUBPERIOD 2 ###############

#1 GBP
armodel1ii<-arima(retsub2[,2], order = c(1,0,1),include.mean = FALSE); summary(armodel1ii)
residuals1ii<-residuals(armodel1ii)
#arch test
#taking standardized residuals
archTest(residuals1ii)#Ljung-Box statistics (Q)
#p-value 0 so null hypothesis rejected-> heteroskedasticity exists in the residuals GARCH model can be used.

#2 JPY
armodel2ii<-arima(retsub2[,3], order = c(0,0,1),include.mean = FALSE); summary(armodel2ii)
residuals2ii<-residuals(armodel2ii)
#arch test
#taking standardized residuals
archTest(residuals2ii)#Ljung-Box statistics (Q)
#significant p-val so heteroskedasticity

#3 TRY
armodel3ii<-arima(retsub2[,4], order = c(0,0,1),include.mean = FALSE); summary(armodel3ii)
residuals3ii<-residuals(armodel3ii)
#arch test
archTest(residuals3ii)#Ljung-Box statistics (Q)
#heteroskedasticity

#4 USD
armodel4ii<-arima(retsub2[,5], order = c(1,0,1),include.mean = FALSE); summary(armodel4ii)
residuals4ii<-residuals(armodel4ii)
#arch test
archTest(residuals4ii)#Ljung-Box statistics (Q)
#heteroskedasticity

########### SUBPERIOD 3 ###############

#1 GBP
armodel1iii<-arima(retsub3[,2], order = c(1,0,1),include.mean = FALSE); summary(armodel1iii)
residuals1iii<-residuals(armodel1iii)
#arch test
#taking standardized residuals
archTest(residuals1iii)#Ljung-Box statistics (Q)
#p-value 0 so null hypothesis rejected-> heteroskedasticity exists in the residuals GARCH model can be used.

#2 JPY
armodel2iii<-arima(retsub3[,3], order = c(0,0,1),include.mean = FALSE); summary(armodel2iii)
residuals2iii<-residuals(armodel2iii)
#arch test
#taking standardized residuals
archTest(residuals2iii)#Ljung-Box statistics (Q)
#significant p-val so heteroskedasticity

#3 TRY
armodel3iii<-arima(retsub3[,4], order = c(2,0,3),include.mean = FALSE); summary(armodel3iii)
residuals3iii<-residuals(armodel3iii)
#arch test
archTest(residuals3iii)#Ljung-Box statistics (Q)
#heteroskedasticity

#4 USD
armodel4iii<-arima(retsub3[,5], order = c(1,0,1),include.mean = FALSE); summary(armodel4iii)
residuals4iii<-residuals(armodel4iii)
#arch test
archTest(residuals4iii)#Ljung-Box statistics (Q)
#heteroskedasticity


#same results for negative returns

############################# FITTING GARCH MODELS ##################################

############## SUBPERIOD 1 ##################

#1 GBP
spec1i<-ugarchspec(mean.model = list(armaOrder=c(2,2)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                  distribution.model = "std")
garchmod1i<-ugarchfit(spec1i,data = retsub1[,2]); garchmod1i
residgarch1i<-residuals(garchmod1i)
#mu and omega = intercept terms
#a1(ut-1^2) and b1(sigmat-1^2) coeff stat sign and positive
#a1+b1=0.90+0.087=0.98 very close to 1
#which means persistent shocks to the cond variance

plot(garchmod1i,which=3)#returns are symbolized by the light color and sd by dark
plot(garchmod1i,which=9)#QQ-plot of resid
plot(garchmod1i,which=10) #no A/C
plot(garchmod1i,which=8)#pos outliers

#2 JPY
spec2i<-ugarchspec(mean.model = list(armaOrder=c(2,2)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                  distribution.model = "std")
garchmod2i<-ugarchfit(spec2i,data = retsub1[,3]); garchmod2i
residgarch2i<-residuals(garchmod2i)

plot(garchmod2i,which=8)#pos outliers

#3 TRY
spec3i<-ugarchspec(mean.model = list(armaOrder=c(0,1)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                  distribution.model = "std")
garchmod3i<-ugarchfit(spec3i,data = retsub1[,4]); garchmod3i
residgarch3i<-residuals(garchmod3i)

plot(garchmod3i,which=8)#pos outliers

#4 USD
spec4i<-ugarchspec(mean.model = list(armaOrder=c(0,1)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                  distribution.model = "std")
garchmod4i<-ugarchfit(spec4i,data = retsub1[,5]); garchmod4i
residgarch4i<-residuals(garchmod4i)

plot(garchmod4i,which=8)#pos outliers#fat tails

#creating matrices for pos and neg residuals
garchresidi = matrix(0,nrow = 1395,ncol = 4)
neggarchresidi = matrix(0,nrow = 1395,ncol = 4)
garchresidi[,1] = residgarch1i; garchresidi[,2] = residgarch2i; garchresidi[,3] = residgarch3i; garchresidi[,4] = residgarch4i
neggarchresidi[,1] = -residgarch1i; neggarchresidi[,2] = -residgarch2i; neggarchresidi[,3] = -residgarch3i; neggarchresidi[,4] = -residgarch4i
garchresidi = as.data.frame(garchresidi)
neggarchresidi = as.data.frame(neggarchresidi)

############# SUBPERIOD 2 ################

#1 GBP
spec1ii<-ugarchspec(mean.model = list(armaOrder=c(0,0)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                   distribution.model = "std")
garchmod1ii<-ugarchfit(spec1ii,data = retsub2[,2]); garchmod1ii
residgarch1ii<-residuals(garchmod1ii)
#mu and omega = intercept terms
#a1(ut-1^2) and b1(sigmat-1^2) coeff stat sign and positive
#a1+b1=0.90+0.087=0.98 very close to 1
#which means persistent shocks to the cond variance

plot(garchmod1ii,which=3)#returns are symbolized by the light color and sd by dark
plot(garchmod1ii,which=9)#QQ-plot of resid
plot(garchmod1ii,which=10) #no A/C
plot(garchmod1ii,which=8)#pos outliers

#2 JPY
spec2ii<-ugarchspec(mean.model = list(armaOrder=c(0,1)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                   distribution.model = "std")
garchmod2ii<-ugarchfit(spec2ii,data = retsub2[,3]); garchmod2ii
residgarch2ii<-residuals(garchmod2ii)

plot(garchmod2ii,which=8)#no outliers

#3 TRY
spec3ii<-ugarchspec(mean.model = list(armaOrder=c(0,0)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                   distribution.model = "std")
garchmod3ii<-ugarchfit(spec3ii,data = retsub2[,4]); garchmod3ii
residgarch3ii<-residuals(garchmod3ii)

plot(garchmod3ii,which=8)#pos outliers

#4 USD
spec4ii<-ugarchspec(mean.model = list(armaOrder=c(0,0)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                   distribution.model = "std")
garchmod4ii<-ugarchfit(spec4ii,data = retsub2[,5]); garchmod4ii
residgarch4ii<-residuals(garchmod4ii)

plot(garchmod4ii,which=8)#pos outliers#fat tails

#creating matrices for pos and neg residuals
garchresidii = matrix(0,nrow = 1396,ncol = 4)
neggarchresidii = matrix(0,nrow = 1396,ncol = 4)
garchresidii[,1] = residgarch1ii; garchresidii[,2] = residgarch2ii; garchresidii[,3] = residgarch3ii; garchresidii[,4] = residgarch4ii
neggarchresidii[,1] = -residgarch1ii; neggarchresidii[,2] = -residgarch2ii; neggarchresidii[,3] = -residgarch3ii; neggarchresidii[,4] = -residgarch4ii
garchresidii = as.data.frame(garchresidii)
neggarchresidii = as.data.frame(neggarchresidii)

################# SUBPERIOD 3 #####################

#1 GBP
spec1iii<-ugarchspec(mean.model = list(armaOrder=c(0,0)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                    distribution.model = "std")
garchmod1iii<-ugarchfit(spec1iii,data = retsub3[,2]); garchmod1iii
residgarch1iii<-residuals(garchmod1iii)
#mu and omega = intercept terms
#a1(ut-1^2) and b1(sigmat-1^2) coeff stat sign and positive
#a1+b1=0.90+0.087=0.98 very close to 1
#which means persistent shocks to the cond variance

plot(garchmod1iii,which=3)#returns are symbolized by the light color and sd by dark
plot(garchmod1iii,which=9)#QQ-plot of resid
plot(garchmod1iii,which=10) #no A/C
plot(garchmod1iii,which=8)#pos outliers

#2 JPY
spec2iii<-ugarchspec(mean.model = list(armaOrder=c(0,0)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                    distribution.model = "std")
garchmod2iii<-ugarchfit(spec2iii,data = retsub3[,3]); garchmod2iii
residgarch2iii<-residuals(garchmod2iii)

plot(garchmod2iii,which=8)#no outliers

#3 TRY
spec3iii<-ugarchspec(mean.model = list(armaOrder=c(2,3)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                    distribution.model = "std")
garchmod3iii<-ugarchfit(spec3iii,data = retsub3[,4]); garchmod3iii
residgarch3iii<-residuals(garchmod3iii)

plot(garchmod3ii,which=8)#pos outliers

#4 USD
spec4iii<-ugarchspec(mean.model = list(armaOrder=c(0,0)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                    distribution.model = "std")
garchmod4iii<-ugarchfit(spec4iii,data = retsub3[,5]); garchmod4iii
residgarch4iii<-residuals(garchmod4iii)

plot(garchmod4iii,which=8)#pos outliers#fat tails

#creating matrices for pos and neg residuals
garchresidiii = matrix(0,nrow = 1396,ncol = 4)
neggarchresidiii = matrix(0,nrow = 1396,ncol = 4)
garchresidiii[,1] = residgarch1iii; garchresidiii[,2] = residgarch2iii; garchresidiii[,3] = residgarch3iii; garchresidiii[,4] = residgarch4iii
neggarchresidiii[,1] = -residgarch1iii; neggarchresidiii[,2] = -residgarch2iii; neggarchresidiii[,3] = -residgarch3iii; neggarchresidiii[,4] = -residgarch4iii
garchresidiii = as.data.frame(garchresidiii)
neggarchresidiii = as.data.frame(neggarchresidiii)

############## bivariate threshold selection plot: ##################

########## SUBPERIOD 1 ###################
u1i = seq(0,max(garchresidi[,1]),0.1); u2i = seq(0,max(garchresidi[,2]),0.1); u3i = seq(0,max(garchresidi[,3]),0.1)
u4i = seq(0,max(garchresidi[,4]),0.1); u5i = seq(0,max(neggarchresidi[,1]),0.1); u6i = seq(0,max(neggarchresidi[,2]),0.1)
u7i = seq(0,max(neggarchresidi[,3]),0.1); u8i = seq(0,max(neggarchresidi[,4]),0.1)

x1i = vector('numeric',length(u1i)); x2i = vector('numeric',length(u2i)); x3i = vector('numeric',length(u3i))
x4i = vector('numeric',length(u4i)); x5i = vector('numeric',length(u5i)); x6i = vector('numeric',length(u6i))
x7i = vector('numeric',length(u7i)); x8i = vector('numeric',length(u8i))

#mean excess of data for each value of u:
#positive
for (i in 1:length(x1i)){
  threshold.exceedances1i = garchresidi$V1[garchresidi$V1>u1i[i]]
  x1i[i] = mean(threshold.exceedances1i-u1i[i])
}
for (i in 1:length(x2i)){
  threshold.exceedances2i = garchresidi$V2[garchresidi$V2>u2i[i]]
  x2i[i] = mean(threshold.exceedances2i-u2i[i])
}
for (i in 1:length(x3i)){
  threshold.exceedances3i = garchresidi$V3[garchresidi$V3>u3i[i]]
  x3i[i] = mean(threshold.exceedances3i-u3i[i])
}
for (i in 1:length(x4i)){
  threshold.exceedances4i = garchresidi$V4[garchresidi$V4>u4i[i]]
  x4i[i] = mean(threshold.exceedances4i-u4i[i])
}
#negative
for (i in 1:length(x5i)){
  threshold.exceedances5i = neggarchresidi$V1[neggarchresidi$V1>u5i[i]]
  x5i[i] = mean(threshold.exceedances5i-u5i[i])
}
for (i in 1:length(x6i)){
  threshold.exceedances6i = neggarchresidi$V2[neggarchresidi$V2>u6i[i]]
  x6i[i] = mean(threshold.exceedances6i-u6i[i])
}
for (i in 1:length(x7i)){
  threshold.exceedances7i = neggarchresidi$V3[neggarchresidi$V3>u7i[i]]
  x7i[i] = mean(threshold.exceedances7i-u7i[i])
}
for (i in 1:length(x8i)){
  threshold.exceedances8i = neggarchresidi$V4[neggarchresidi$V4>u8i[i]]
  x8i[i] = mean(threshold.exceedances8i-u8i[i])
}

par(mfrow = c(1,1))
plot(x1i~u1i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.7), col="blue", lty=3, lwd=0.5)

plot(x2i~u2i,type = "l",main = "Mean Residual Life Plot", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,8,0.2))
abline(v=(0.7), col="blue", lty=3, lwd=0.5)

plot(x3i~u3i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)

plot(x4i~u4i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,15,0.2))
abline(v=(0.8), col="blue", lty=3, lwd=0.5)

plot(x5i~u5i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.65), col="blue", lty=3, lwd=0.5)

plot(x6i~u6i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.9), col="blue", lty=3, lwd=0.5)

plot(x7i~u7i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(1.2), col="blue", lty=3, lwd=0.5)

plot(x8i~u8i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,14,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)


ui = matrix(0,nrow = 1,ncol = 8)
ui[] = c(0.7, 0.7, 0.7, 0.7, 0.65, 0.85, 1.1, 0.75)
#ui[] = c(0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2)

exceedances1i = garchresidi$V1[garchresidi$V1>ui[1]]; y1i = exceedances1i - ui[1]; k1i = length(y1i)
exceedances2i = garchresidi$V2[garchresidi$V2>ui[2]]; y2i = exceedances2i - ui[2]; k2i = length(y2i)
exceedances3i = garchresidi$V3[garchresidi$V3>ui[3]]; y3i = exceedances3i - ui[3]; k3i = length(y3i)
exceedances4i = garchresidi$V4[garchresidi$V4>ui[4]]; y4i = exceedances4i - ui[4]; k4i = length(y4i)
#negative:
exceedances5i = neggarchresidi$V1[neggarchresidi$V1>ui[5]]; y5i = exceedances5i - ui[5]; k5i = length(y5i)
exceedances6i = neggarchresidi$V2[neggarchresidi$V2>ui[6]]; y6i = exceedances6i - ui[6]; k6i = length(y6i)
exceedances7i = neggarchresidi$V3[neggarchresidi$V3>ui[7]]; y7i = exceedances7i - ui[7]; k7i = length(y7i)
exceedances8i = neggarchresidi$V4[neggarchresidi$V4>ui[8]]; y8i = exceedances8i - ui[8]; k8i = length(y8i)

hillPlot(x = y1i); abline(v=(45), col="red", lty=3, lwd=0.5); #u=0.9
legend("topright", c("EUR/GBP - right tail", "u = 1"))

hillPlot(x = y2i); abline(v=(115), col="red", lty=3, lwd=0.5); #u=0.65
legend("topright", c("EUR/JPY - right tail", "u = 0.85"))

hillPlot(x = y3i); abline(v=(230), col="red", lty=3, lwd=0.5); #u=0.7
legend("topright", c("EUR/GBP - right tail", "u = 1"))

hillPlot(x = y4i); abline(v=(115), col="red", lty=3, lwd=0.5); #u=0.6
legend("topright", c("EUR/GBP - right tail", "u = 1"))

hillPlot(x = y5i); abline(v=(60), col="red", lty=3, lwd=0.5); #u=0.7
legend("topright", c("EUR/GBP - right tail", "u = 1"))

hillPlot(x = y6i); abline(v=(140), col="red", lty=3, lwd=0.5); #u=0.8
legend("topright", c("EUR/GBP - right tail", "u = 1"))

hillPlot(x = y7i); abline(v=(138), col="red", lty=3, lwd=0.5); #u=1
hillPlot(x = y8i); abline(v=(70), col="red", lty=3, lwd=0.5); #u=0.9



################## SUBPERIOD 2 ####################

u1ii = seq(0,max(garchresidii[,1]),0.1); u2ii = seq(0,max(garchresidii[,2]),0.1); u3ii = seq(0,max(garchresidii[,3]),0.1)
u4ii = seq(0,max(garchresidii[,4]),0.1); u5ii = seq(0,max(neggarchresidii[,1]),0.1); u6ii = seq(0,max(neggarchresidii[,2]),0.1)
u7ii = seq(0,max(neggarchresidii[,3]),0.1); u8ii = seq(0,max(neggarchresidii[,4]),0.1)

x1ii = vector('numeric',length(u1ii)); x2ii = vector('numeric',length(u2ii)); x3ii = vector('numeric',length(u3ii))
x4ii = vector('numeric',length(u4ii)); x5ii = vector('numeric',length(u5ii)); x6ii = vector('numeric',length(u6ii))
x7ii = vector('numeric',length(u7ii)); x8ii = vector('numeric',length(u8ii))

#mean excess of data for each value of u:
#positive
for (i in 1:length(x1ii)){
  threshold.exceedances1ii = garchresidii$V1[garchresidii$V1>u1ii[i]]
  x1ii[i] = mean(threshold.exceedances1ii-u1ii[i])
}
for (i in 1:length(x2ii)){
  threshold.exceedances2ii = garchresidii$V2[garchresidii$V2>u2ii[i]]
  x2ii[i] = mean(threshold.exceedances2ii-u2ii[i])
}
for (i in 1:length(x3ii)){
  threshold.exceedances3ii = garchresidii$V3[garchresidii$V3>u3ii[i]]
  x3ii[i] = mean(threshold.exceedances3ii-u3ii[i])
}
for (i in 1:length(x4ii)){
  threshold.exceedances4ii = garchresidii$V4[garchresidii$V4>u4ii[i]]
  x4ii[i] = mean(threshold.exceedances4ii-u4ii[i])
}
#negative
for (i in 1:length(x5ii)){
  threshold.exceedances5ii = neggarchresidii$V1[neggarchresidii$V1>u5ii[i]]
  x5ii[i] = mean(threshold.exceedances5ii-u5ii[i])
}
for (i in 1:length(x6ii)){
  threshold.exceedances6ii = neggarchresidii$V2[neggarchresidii$V2>u6ii[i]]
  x6ii[i] = mean(threshold.exceedances6ii-u6ii[i])
}
for (i in 1:length(x7ii)){
  threshold.exceedances7ii = neggarchresidii$V3[neggarchresidii$V3>u7ii[i]]
  x7ii[i] = mean(threshold.exceedances7ii-u7ii[i])
}
for (i in 1:length(x8ii)){
  threshold.exceedances8ii = neggarchresidii$V4[neggarchresidii$V4>u8ii[i]]
  x8ii[i] = mean(threshold.exceedances8ii-u8ii[i])
}

plot(x1ii~u1ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.8), col="blue", lty=3, lwd=0.5)

plot(x2ii~u2ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,8,0.2))
abline(v=(0.9), col="blue", lty=3, lwd=0.5)

plot(x3ii~u3ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.65), col="blue", lty=3, lwd=0.5)

plot(x4ii~u4ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,15,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)

plot(x5ii~u5ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)

plot(x6ii~u6ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.7), col="blue", lty=3, lwd=0.5)

plot(x7ii~u7ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)

plot(x8ii~u8ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,14,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)


uii = matrix(0,nrow = 1,ncol = 8)
uii[] = c(0.7, 0.9, 0.7, 0.6, 0.6, 0.7, 0.7, 0.7)
#uii[] = c(0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2)

exceedances1ii = garchresidii$V1[garchresidii$V1>uii[1]]; y1ii = exceedances1ii - uii[1]; k1ii = length(y1ii)
exceedances2ii = garchresidii$V2[garchresidii$V2>uii[2]]; y2ii = exceedances2ii - uii[2]; k2ii = length(y2ii)
exceedances3ii = garchresidii$V3[garchresidii$V3>uii[3]]; y3ii = exceedances3ii - uii[3]; k3ii = length(y3ii)
exceedances4ii = garchresidii$V4[garchresidii$V4>uii[4]]; y4ii = exceedances4ii - uii[4]; k4ii = length(y4ii)
#negative:
exceedances5ii = neggarchresidii$V1[neggarchresidii$V1>uii[5]]; y5ii = exceedances5ii - uii[5]; k5ii = length(y5ii)
exceedances6ii = neggarchresidii$V2[neggarchresidii$V2>uii[6]]; y6ii = exceedances6ii - uii[6]; k6ii = length(y6ii)
exceedances7ii = neggarchresidii$V3[neggarchresidii$V3>uii[7]]; y7ii = exceedances7ii - uii[7]; k7ii = length(y7ii)
exceedances8ii = neggarchresidii$V4[neggarchresidii$V4>uii[8]]; y8ii = exceedances8ii - uii[8]; k8ii = length(y8ii)

hillPlot(x = y1ii); abline(v=(55), col="red", lty=3, lwd=0.5); #u=0.65
legend("topright", c("EUR/GBP - right tail", "u = 1"))
hillPlot(x = y2ii); abline(v=(90), col="red", lty=3, lwd=0.5); #u=0.9
hillPlot(x = y3ii); abline(v=(110), col="red", lty=3, lwd=0.5); #u=0.75
hillPlot(x = y4ii); abline(v=(120), col="red", lty=3, lwd=0.5); #u=0.6
hillPlot(x = y5ii); abline(v=(64), col="red", lty=3, lwd=0.5); #u=0.65
hillPlot(x = y6ii); abline(v=(115), col="red", lty=3, lwd=0.5); #u=0.8
hillPlot(x = y7ii); abline(v=(75), col="red", lty=3, lwd=0.5); #u=0.8
hillPlot(x = y8ii); abline(v=(70), col="red", lty=3, lwd=0.5); #u=0.85

################## SUBPERIOD 3 ####################
u1iii = seq(0,max(garchresidiii[,1]),0.1); u2iii = seq(0,max(garchresidiii[,2]),0.1); u3iii = seq(0,max(garchresidiii[,3]),0.1)
u4iii = seq(0,max(garchresidiii[,4]),0.1); u5iii = seq(0,max(neggarchresidiii[,1]),0.1); u6iii = seq(0,max(neggarchresidiii[,2]),0.1)
u7iii = seq(0,max(neggarchresidiii[,3]),0.1); u8iii = seq(0,max(neggarchresidiii[,4]),0.1)

x1iii = vector('numeric',length(u1iii)); x2iii = vector('numeric',length(u2iii)); x3iii = vector('numeric',length(u3iii))
x4iii = vector('numeric',length(u4iii)); x5iii = vector('numeric',length(u5iii)); x6iii = vector('numeric',length(u6iii))
x7iii = vector('numeric',length(u7iii)); x8iii = vector('numeric',length(u8iii))

#mean excess of data for each value of u:
#positive
for (i in 1:length(x1iii)){
  threshold.exceedances1iii = garchresidiii$V1[garchresidiii$V1>u1iii[i]]
  x1iii[i] = mean(threshold.exceedances1iii-u1iii[i])
}
for (i in 1:length(x2iii)){
  threshold.exceedances2iii = garchresidiii$V2[garchresidiii$V2>u2iii[i]]
  x2iii[i] = mean(threshold.exceedances2iii-u2iii[i])
}
for (i in 1:length(x3iii)){
  threshold.exceedances3iii = garchresidiii$V3[garchresidiii$V3>u3iii[i]]
  x3iii[i] = mean(threshold.exceedances3iii-u3iii[i])
}
for (i in 1:length(x4iii)){
  threshold.exceedances4iii = garchresidiii$V4[garchresidiii$V4>u4iii[i]]
  x4iii[i] = mean(threshold.exceedances4iii-u4iii[i])
}
#negative
for (i in 1:length(x5iii)){
  threshold.exceedances5iii = neggarchresidiii$V1[neggarchresidiii$V1>u5iii[i]]
  x5iii[i] = mean(threshold.exceedances5iii-u5iii[i])
}
for (i in 1:length(x6iii)){
  threshold.exceedances6iii = neggarchresidiii$V2[neggarchresidiii$V2>u6iii[i]]
  x6iii[i] = mean(threshold.exceedances6iii-u6iii[i])
}
for (i in 1:length(x7iii)){
  threshold.exceedances7iii = neggarchresidiii$V3[neggarchresidiii$V3>u7iii[i]]
  x7iii[i] = mean(threshold.exceedances7iii-u7iii[i])
}
for (i in 1:length(x8iii)){
  threshold.exceedances8iii = neggarchresidiii$V4[neggarchresidiii$V4>u8iii[i]]
  x8iii[i] = mean(threshold.exceedances8iii-u8iii[i])
}

plot(x1iii~u1iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.9), col="blue", lty=3, lwd=0.5)

plot(x2iii~u2iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,8,0.2))
abline(v=(0.5), col="blue", lty=3, lwd=0.5)

plot(x3iii~u3iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,14,0.2))
abline(v=(1), col="blue", lty=3, lwd=0.5)

plot(x4iii~u4iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,15,0.2))
abline(v=(0.75), col="blue", lty=3, lwd=0.5)

plot(x5iii~u5iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.4), col="blue", lty=3, lwd=0.5)

plot(x6iii~u6iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.65), col="blue", lty=3, lwd=0.5)

plot(x7iii~u7iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(1.2), col="blue", lty=3, lwd=0.5)

plot(x8iii~u8iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,14,0.2))
abline(v=(0.55), col="blue", lty=3, lwd=0.5)


uiii = matrix(0,nrow = 1,ncol = 8)
uiii[] = c(0.8, 0.5, 1.1, 0.65, 0.5, 0.6, 1.2, 0.6)
#uiii[] = c(0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2)

exceedances1iii = garchresidiii$V1[garchresidiii$V1>uiii[1]]; y1iii = exceedances1iii - uiii[1]; k1iii = length(y1iii)
exceedances2iii = garchresidiii$V2[garchresidiii$V2>uiii[2]]; y2iii = exceedances2iii - uiii[2]; k2iii = length(y2iii)
exceedances3iii = garchresidiii$V3[garchresidiii$V3>uiii[3]]; y3iii = exceedances3iii - uiii[3]; k3iii = length(y3iii)
exceedances4iii = garchresidiii$V4[garchresidiii$V4>uiii[4]]; y4iii = exceedances4iii - uiii[4]; k4iii = length(y4iii)
#negative:
exceedances5iii = neggarchresidiii$V1[neggarchresidiii$V1>uiii[5]]; y5iii = exceedances5iii - uiii[5]; k5iii = length(y5iii)
exceedances6iii = neggarchresidiii$V2[neggarchresidiii$V2>uiii[6]]; y6iii = exceedances6iii - uiii[6]; k6iii = length(y6iii)
exceedances7iii = neggarchresidiii$V3[neggarchresidiii$V3>uiii[7]]; y7iii = exceedances7iii - uiii[7]; k7iii = length(y7iii)
exceedances8iii = neggarchresidiii$V4[neggarchresidiii$V4>uiii[8]]; y8iii = exceedances8iii - uiii[8]; k8iii = length(y8iii)

hillPlot(x = y1iii); abline(v=(95), col="red", lty=3, lwd=0.5); #u=0.55 or 0.7
legend("topright", c("EUR/GBP - right tail", "u = 1"))
hillPlot(x = y2iii); abline(v=(85), col="red", lty=3, lwd=0.5); #u=0.55
hillPlot(x = y3iii); abline(v=(70), col="red", lty=3, lwd=0.5); #u=1.3
hillPlot(x = y4iii); abline(v=(90), col="red", lty=3, lwd=0.5); #u=0.5
hillPlot(x = y5iii); abline(v=(60), col="red", lty=3, lwd=0.5); #u=0.65
hillPlot(x = y6iii); abline(v=(100), col="red", lty=3, lwd=0.5); #u=0.55
hillPlot(x = y7iii); abline(v=(65), col="red", lty=3, lwd=0.5); #u=1.2
hillPlot(x = y8iii); abline(v=(35), col="red", lty=3, lwd=0.5) #u=0.65

############################# MLE ESTIMATION OF BIV EVT MODELS + PLOTS #################################


############# SUBPERIOD 1 ############
par(mfrow=c(1,2))
m1i = fitbvgpd(data = garchresidi[,c(1,2)],threshold = ui[1:2],model = "log"); m1i; m1i$chi #1. GBP � JPY
plot(m1i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
#pickands plot: horizontal line is independence, other 2 perfect dependence
chiplot(data = garchresidi[,c(1,2)],which = c(1,2),ask = F)
taildep(x = garchresidi[,c(1,2)],u = 0.99,type = 'chibar')
taildep.test(x = garchresidi[,c(1,2)], cthresh = -0.4) #inde
#ind
m2i = fitbvgpd(data = garchresidi[,c(1,3)],threshold = ui[c(1,3)],model = "log");  m2i ; m2i$chi #2.	GBP � TRY
plot(m2i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidi[,c(1,3)],which = c(1,2),ask = F)
#ind
m3i = fitbvgpd(data = garchresidi[,c(1,4)],threshold = ui[c(1,4)],model = "log"); m3i; m3i$chi #3.	GBP � USD
plot(m3i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidi[,c(1,4)],which = c(1,2),ask = F)
#ind
m4i = fitbvgpd(data = garchresidi[,c(2,3)],threshold = ui[c(2,3)],model = "log"); m4i; m4i$chi# 4.	JPY � TRY
plot(m4i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidi[,c(2,3)],which = c(1,2),ask = F)
#ind
m5i = fitbvgpd(data = garchresidi[,,c(2,4)],threshold = ui[c(2,4)],model = "log"); m5i; m5i$chi# 5.	JPY � USD
plot(m5i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidi[,c(2,4)],which = c(1,2),ask = F)
#ind
m6i = fitbvgpd(data = garchresidi[,c(3,4)],threshold = ui[c(3,4)],model = "log"); m6i; m6i$chi# 6.	TRY � USD
plot(m6i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidi[,c(3,4)],which = c(1,2),ask = F)
#ind
m7i = fitbvgpd(data = neggarchresidi[,c(1,2)],threshold = ui[c(5,6)],model = "log"); m7i; m7i$chi #1. GBP � JPY
plot(m7i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidi[,c(1,2)],which = c(1,2),ask = F)
#ind
m8i = fitbvgpd(data = neggarchresidi[,c(1,3)],threshold = ui[c(5,7)],model = "log");  m8i ; m8i$chi #2.	GBP � TRY
plot(m8i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidi[,c(1,3)],which = c(1,2),ask = F)
#ind
m9i = fitbvgpd(data = neggarchresidi[,c(1,4)],threshold = ui[c(5,8)],model = "log"); m9i; m9i$chi #3.	GBP � USD
plot(m9i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidi[,c(1,4)],which = c(1,2),ask = F)
#ind
m10i = fitbvgpd(data = neggarchresidi[,c(2,3)],threshold = ui[c(6,7)],model = "log"); m10i; m10i$chi# 4.	JPY � TRY
plot(m10i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidi[,c(2,3)],which = c(1,2),ask = F)
#ind
m11i = fitbvgpd(data = neggarchresidi[,c(2,4)],threshold = ui[c(6,8)],model = "log"); m11i; m11i$chi# 5.	JPY � USD
plot(m11i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidi[,c(2,4)],which = c(1,2),ask = F)
chi11i = chiplot(data = neggarchresidi[,c(2,4)],which = c(1,2),ask = F)
chi11i$chibar[100,2]
#ind
m12i = fitbvgpd(data = neggarchresidi[,c(3,4)],threshold = ui[c(7,8)],model = "log"); m12i; m12i$chi# 6.	TRY � USD
plot(m12i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidi[,c(3,4)],which = c(1,2),ask = F)
#ind
############### SUBPERIOD 2 ##############

m1ii = fitbvgpd(data = garchresidii[,c(1,2)],threshold = uii[1:2],model = "log"); m1ii; m1ii$chi #1. GBP � JPY
plot(m1ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
#pickands plot: horizontal line is independence, other 2 perfect dependence
chiplot(data = garchresidii[,c(1,2)],which = c(1,2),ask = F)
#ind
m2ii = fitbvgpd(data = garchresidii[,c(1,3)],threshold = uii[c(1,3)],model = "log");  m2ii ; m2ii$chi #2.	GBP � TRY
plot(m2ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidii[,c(1,3)],which = c(1,2),ask = F)
#ind
m3ii = fitbvgpd(data = garchresidii[,c(1,4)],threshold = uii[c(1,4)],model = "log"); m3ii; m3ii$chi #3.	GBP � USD
plot(m3ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidii[,c(1,4)],which = c(1,2),ask = F)
taildep.test(x = garchresidii[,c(1,4)], cthresh = -0.35)#p-value<0.05 so null rejected so tail  independence
taildep(x = garchresidii[,c(1,4)],type = 'chibar',u = 0.99)
#ind
m4ii = fitbvgpd(data = garchresidii[,c(2,3)],threshold = uii[c(2,3)],model = "log"); m4ii; m4ii$chi# 4.	JPY � TRY
plot(m4ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidii[,c(2,3)],which = c(1,2),ask = F)
#ind
m5ii = fitbvgpd(data = garchresidii[,,c(2,4)],threshold = uii[c(2,4)],model = "log"); m5ii; m5ii$chi# 5.	JPY � USD
plot(m5ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidii[,c(2,4)],which = c(1,2),ask = F)
#ind
m6ii = fitbvgpd(data = garchresidii[,c(3,4)],threshold = uii[c(3,4)],model = "log"); m6ii; m6ii$chi# 6.	TRY � USD
plot(m6ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidii[,c(3,4)],which = c(1,2),ask = F)
#ind
m7ii = fitbvgpd(data = neggarchresidii[,c(1,2)],threshold = uii[c(5,6)],model = "log"); m7ii; m7ii$chi #1. GBP � JPY
plot(m7ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidii[,c(1,2)],which = c(1,2),ask = F)
taildep.test(x = neggarchresidii[,c(1,2)], cthresh = -0.4)#p-value<0.05 so null rejected so tail  independence
taildep(x = neggarchresidii[,c(1,2)],type = 'chibar',u = 0.99)
#ind()
m8ii = fitbvgpd(data = neggarchresidii[,c(1,3)],threshold = uii[c(5,7)],model = "log");  m8ii ; m8ii$chi #2.	GBP � TRY
plot(m8ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidii[,c(1,3)],which = c(1,2),ask = F)
taildep(x =  neggarchresidii[,c(1,3)], type = 'chibar', u = 0.99)
taildep.test(x =  neggarchresidii[,c(1,3)], cthresh = -0.4) #null rej so tail independence 
#ind()
m9ii = fitbvgpd(data = neggarchresidii[,c(1,4)],threshold = uii[c(5,8)],model = "log"); m9ii; m9ii$chi #3.	GBP � USD
plot(m9ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidii[,c(1,4)],which = c(1,2),ask = F)
taildep(x =  neggarchresidii[,c(1,4)], type = 'chibar', u = 0.99)
taildep.test(x =  neggarchresidii[,c(1,4)], cthresh = -0.3) #null not rej so Dependence 
#DEPEND
m10ii = fitbvgpd(data = neggarchresidii[,c(2,3)],threshold = uii[c(6,7)],model = "log"); m10ii; m10ii$chi# 4.	JPY � TRY
plot(m10ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidii[,c(2,3)],which = c(1,2),ask = F)
taildep(x =  neggarchresidii[,c(2,3)], type = 'chibar', u = 0.99)
taildep.test(x =  neggarchresidii[,c(2,3)], cthresh = -0.4) #null rej so tail independence 
#ind
m11ii = fitbvgpd(data = neggarchresidii[,c(2,4)],threshold = uii[c(6,8)],model = "log"); m11ii; m11ii$chi# 5.	JPY � USD
plot(m11ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidii[,c(2,4)],which = c(1,2),ask = F)
taildep(x =  neggarchresidii[,c(2,4)], type = 'chibar', u = 0.99)
taildep.test(x =  neggarchresidii[,c(2,3)], cthresh = -0.4) #null rej so tail independence 
#ind()
m12ii = fitbvgpd(data = neggarchresidii[,c(3,4)],threshold = uii[c(7,8)],model = "log"); m12ii; m12ii$chi# 6.	TRY � USD
plot(m12ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidii[,c(3,4)],which = c(1,2),ask = F)
taildep(x =  neggarchresidii[,c(3,4)], type = 'chibar', u = 0.99)
taildep.test(x =  neggarchresidii[,c(3,4)], cthresh = -0.4) #null rej so tail independence 
#ind
############### SUBPERIOD 3 ##############

m1iii = fitbvgpd(data = garchresidiii[,c(1,2)],threshold = uiii[1:2],model = "log"); m1iii; m1iii$chi #1. GBP � JPY
plot(m1iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
#pickands plot: horizontal line is independence, other 2 perfect dependence
chiplot(data = garchresidiii[,c(1,2)],which = c(1,2),ask = F)
#ind
m2iii = fitbvgpd(data = garchresidiii[,c(1,3)],threshold = uiii[c(1,3)],model = "log");  m2iii ; m2iii$chi #2.	GBP � TRY
plot(m2iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidiii[,c(1,3)],which = c(1,2),ask = F)
#ind
m3iii = fitbvgpd(data = garchresidiii[,c(1,4)],threshold = uiii[c(1,4)],model = "log"); m3iii; m3iii$chi #3.	GBP � USD
plot(m3iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidiii[,c(1,4)],which = c(1,2),ask = F)
#ind
m4iii = fitbvgpd(data = garchresidiii[,c(2,3)],threshold = uiii[c(2,3)],model = "log"); m4iii; m4iii$chi# 4.	JPY � TRY
plot(m4iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidiii[,c(2,3)],which = c(1,2),ask = F)
#ind
m5iii = fitbvgpd(data = garchresidiii[,c(2,4)],threshold = uiii[c(2,4)],model = "log"); m5iii; m5iii$chi# 5.	JPY � USD
plot(m5iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidiii[,c(2,4)],which = c(1,2),ask = F)
taildep(x = garchresidiii[,c(2,4)],u = 0.99, type = "chibar")
taildep.test(x = garchresidiii[,c(2,4)],cthresh = -0.4) #null not rejected so dependence
#DEP
m6iii = fitbvgpd(data = garchresidiii[,c(3,4)],threshold = uiii[c(3,4)],model = "log"); m6iii; m6iii$chi# 6.	TRY � USD
plot(m6iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = garchresidiii[,c(3,4)],which = c(1,2),ask = F)
#ind
m7iii = fitbvgpd(data = neggarchresidiii[,c(1,2)],threshold = uiii[c(5,6)],model = "log"); m7iii; m7iii$chi #1. GBP � JPY
plot(m7iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidiii[,c(1,2)],which = c(1,2),ask = F)
#ind
m8iii = fitbvgpd(data = neggarchresidiii[,c(1,3)],threshold = uiii[c(5,7)],model = "log");  m8iii ; m8iii$chi #2.	GBP � TRY
plot(m8iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidiii[,c(1,3)],which = c(1,2),ask = F)
#ind
m9iii = fitbvgpd(data = neggarchresidiii[,c(1,4)],threshold = uiii[c(5,8)],model = "log"); m9iii; m9iii$chi #3.	GBP � USD
plot(m9iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidiii[,c(1,4)],which = c(1,2),ask = F)
#ind
m10iii = fitbvgpd(data = neggarchresidiii[,c(2,3)],threshold = uiii[c(6,7)],model = "log"); m10iii; m10iii$chi# 4.	JPY � TRY
plot(m10iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidiii[,c(2,3)],which = c(1,2),ask = F)
#ind
m11iii = fitbvgpd(data = neggarchresidiii[,c(2,4)],threshold = uiii[c(6,8)],model = "log"); m11iii; m11iii$chi# 5.	JPY � USD
plot(m11iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidiii[,c(2,4)],which = c(1,2),ask = F)
taildep(x = neggarchresidiii[,c(2,4)],u = 0.99, type = "chibar")
taildep.test(x = neggarchresidiii[,c(2,4)],cthresh = -0.4) #null rejected so independence
#ind
m12iii = fitbvgpd(data = neggarchresidiii[,c(3,4)],threshold = uiii[c(7,8)],model = "log"); m12iii; m12iii$chi# 6.	TRY � USD
plot(m12iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = neggarchresidiii[,c(3,4)],which = c(1,2),ask = F)
#ind
