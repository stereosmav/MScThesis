GPD.INV = function(X,sigma_hat,ksi){
  if (ksi == 0){
    INV = u[1] - sigma_hat*exp(X)
  }
  else{
    INV = u[1] + sigma_hat/ksi * (X^(-ksi) - 1)
  }
  return(INV)
}