###### PACKAGES ########

library(ggplot2)
library(ggpubr)
library(tseries)
library(moments)

################################# IMPORTING DATA, CLEANING & CALCULATING RETURNS + BASIC PLOTS ######################################
#importing dataset:
EURGBP = read.csv('EURGBP=X.csv',header = T,sep = ',',dec = '.',na.strings = 'null')
EURJPY = read.csv('EURJPY=X.csv',header = T,sep = ',',dec = '.',na.strings = 'null')
EURTRY = read.csv('EURTRY=X.csv',header = T,sep = ',',dec = '.',na.strings = 'null')
EURUSD = read.csv('EURUSD=X.csv',header = T,sep = ',',dec = '.',na.strings = 'null')

rates = matrix(data = 0,nrow = 4240,ncol = 5)
rates[,1] = EURGBP[,1]
rates[,2] = EURGBP[,6]
rates[,3] = EURJPY[,6]
rates[,4] = EURTRY[,6]
rates[,5] = EURUSD[,6]
rates = as.data.frame(rates)

#keep only complete cases(no NA rows)
rates = rates[complete.cases(rates), ]

str(rates)
summary(rates) 

#NAs made all columns characters so converting to numeric 
for (t in 2:5){
  rates[,t] = as.numeric(as.character(rates[,t]))
}

#convert first column from character to dates
rates[,1] = as.Date(as.character(rates[,1]))

#final dataset structure
colnames(rates) = c('Date','EURGBP','EURJPY','EURTRY','EURUSD')
str(rates)
summary(rates)

#plots of the prices. 
par(mfrow = c(2,2))
plot(rates$Date,rates$EURGBP,type = 'l',xlab = '',ylab = '',main = '(i) EUR/GBP rate',frame.plot = F,ylim = c(0.65,1.05))
plot(rates$Date,rates$EURJPY,type = 'l',xlab = '',ylab = '',main = '(ii) EUR/JPY rate',frame.plot = F,ylim = c(90,180))
plot(rates$Date,rates$EURTRY,type = 'l',xlab = '',ylab = '',main = '(iii) EUR/TRY rate',frame.plot = F,ylim = c(1,10))
plot(rates$Date,rates$EURUSD,type = 'l',xlab = '',ylab = '',main = '(iv) EUR/USD rate',frame.plot = F,ylim = c(1,1.7))

par(mfrow = c(1,1))
plot(rates$Date,1/rates$EURTRY,type = 'l',xlab = '',ylab = '',main = '1 / EUR/TRY rate',frame.plot = F)
#by plotting the inverse of the EUR/TRY we get the course of the rates for TRY compared to EUR and as we see it is declining.

#calculate log-returns:
returns = rates
for (i in 2:5){
  returns[2:4187,i] = diff(log(x = returns[,i]),lag = 1)
}
returns[1,2:5] = 0

#multiply log returns by 100
returns[,2:5] = returns[,2:5]*100
str(returns)
summary(returns)

#plots of returns.
par(mfrow = c(2,2))
plot(returns$Date,returns$EURGBP,type = 'l',xlab = '',ylab = '',main = '(i) EUR/GBP returns',frame.plot = F,ylim = c(-4,6))
abline(h=0, col="red")
plot(returns$Date,returns$EURJPY,type = 'l',xlab = '',ylab = '',main = '(ii) EUR/JPY returns',frame.plot = F)
abline(h=0, col="red")
plot(returns$Date,returns$EURTRY,type = 'l',xlab = '',ylab = '',main = '(iii) EUR/TRY returns',frame.plot = F)
abline(h=0, col="red")
plot(returns$Date,returns$EURUSD,type = 'l',xlab = '',ylab = '',main = '(iv) EUR/USD returns',frame.plot = F, ylim = c(-15,15))
abline(h=0, col="red")

 #returns look stationary

############################### DESCRIPTIVE STATISTICS #####################################

#we have mean, min and max from str above...

#standard deviation:
for (t in 2:5){ 
  print(colnames(returns[t]))
 print(sd(returns[,t]))
}

#skewness:
for (t in 2:5){ 
  print(colnames(returns[t]))
  print(skewness(returns[,t]))
}

#kurtosis
for (t in 2:5){ 
  print(colnames(returns[t]))
  print(kurtosis(returns[,t]))
}

#jarque-bera test for normality:
for (t in 2:5){
  print(colnames(returns[t]))
  print(jarque.bera.test(returns[,t]))
}

#Ljung-box Q test for autocorrelation.
for (t in 2:5){
  print(colnames(returns[t]))
  print(Box.test(x = returns[,t],type = "Ljung-Box"))
}

#Augmented Dickey fuller test for unit root:
for (t in 2:5){
  print(colnames(returns[t]))
  print(adf.test(x = returns[,t]))
}


#Histograms:
m = c(0,0,0,0)
std = c(0,0,0,0)

for (t in 1:4){
  m[t] = mean(returns[,t+1])
  std[t] = sqrt(var(returns[,t+1]))
}

par(mfrow = c(1,1))
hist(x = returns$EURGBP,main = "i) Histogram EUR/GBP returns",xlab = '',probability = T, breaks =  seq(min(returns[,2]), max(returns[,2]), length.out = 50))
curve(dnorm(x, mean=m[1], sd=std[1]), 
      col="black",lwd=2, add=TRUE, yaxt="n")
hist(x = returns$EURJPY,main = "ii) Histogram EUR/JPY returns",xlab = '',probability = T,breaks = seq(min(returns[,3]), max(returns[,3]), length.out = 50))
curve(dnorm(x, mean=m[2], sd=std[2]), 
      col="black", lwd=2, add=TRUE, yaxt="n")
hist(x = returns$EURTRY,main = "iii) Histogram EUR/TRY returns",xlab = '',probability = T, breaks = seq(min(returns[,4]), max(returns[,4]), length.out = 60))
curve(dnorm(x, mean=m[3], sd=std[3]), 
      col="black", lwd=2, add=TRUE, yaxt="n")
hist(x = returns$EURUSD,main = "iv) Histogram EUR/USD returns",xlab = '',probability = T, breaks = seq(min(returns[,5]), max(returns[,5]), length.out = 60))
curve(dnorm(x, mean=m[4], sd=std[4]), 
      col="black", lwd=2, add=TRUE, yaxt="n")

#acf
par(mfrow = c(2,2))
acf(x = returns$EURGBP,main = "i) EUR/GBP")#no significant signs of autocorr
acf(x = returns$EURJPY,main = "ii) EUR/JPY")#sign neg autocorr at lag=1
acf(x = returns$EURTRY,main = "iii) EUR/TRY")#sign neg autocorr at lags 1:3
acf(x = returns$EURUSD,main = "iv) EUR/USD")#negative autocorr at lag=1

pacf(x = returns$EURGBP,main = "i) EUR/GBP") #significant in different lags
pacf(x = returns$EURJPY,main = "ii) EUR/JPY")#a few significant lags
pacf(x = returns$EURTRY,main = "iii) EUR/TRY")# >> >>
pacf(x = returns$EURUSD,main = "iv) EUR/USD")## >> >>

write.csv(x = returns,file = "exch_rate_returns.csv",col.names = T, row.names = F)

#################################### UNIVARIATE EVT ##################################################


