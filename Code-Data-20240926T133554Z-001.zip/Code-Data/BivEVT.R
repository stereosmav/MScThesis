########## PACKAGES ###############

library(ggpubr)
library(tseries)
library(moments)
library(evd)
library(POT)
library(fExtremes)

############# IMPORTING DATA ########################

returns = read.csv(file = "exch_rate_returns.csv",header = T,sep = ",",dec = ".")
returns = returns[,2:6]

neg_returns = read.csv(file = "exch_rate_neg_returns.csv",header = T,sep = ",",dec = ".")

#################### Estimating biv. EVT for 3 subperiods ###############################

#subperiods for pos returns:
retsub1 = returns[1:1395,] #2005-01-03 - 2010-06-15
retsub2 = returns[1396:2791,]#2010-06-16 - 2015-10-26
retsub3 = returns[2792:4187,]#2015-10-27 - 2021-04-02

#subperiods for neg returns:
negretsub1 = neg_returns[1:1395,]#2005-01-03 - 2010-06-15
negretsub2 = neg_returns[1396:2791,]#2010-06-16 - 2015-10-26 
negretsub3 = neg_returns[2792:4187,]#2015-10-27 - 2021-04-02

############## bivariate threshold selection plot: ##################

########## SUBPERIOD 1 ###################
u1i = seq(0,max(retsub1[,2]),0.1); u2i = seq(0,max(retsub1[,3]),0.1);u3i = seq(0,max(retsub1[,4]),0.1)
u4i = seq(0,max(retsub1[,5]),0.1); u5i = seq(0,max(negretsub1[,2]),0.1); u6i = seq(0,max(negretsub1[,3]),0.1)
u7i = seq(0,max(negretsub1[,4]),0.1); u8i = seq(0,max(negretsub1[,5]),0.1)

x1i = vector('numeric',length(u1i)); x2i = vector('numeric',length(u2i)); x3i = vector('numeric',length(u3i))
x4i = vector('numeric',length(u4i)); x5i = vector('numeric',length(u5i)); x6i = vector('numeric',length(u6i))
x7i = vector('numeric',length(u7i)); x8i = vector('numeric',length(u8i))

for (i in 1:length(x1i)){
  threshold.exceedances1i = retsub1[,2][retsub1[,2]>u1i[i]]
  x1i[i] = mean(threshold.exceedances1i-u1i[i])
}
for (i in 1:length(x2i)){
  threshold.exceedances2i = retsub1[,3][retsub1[,3]>u2i[i]]
  x2i[i] = mean(threshold.exceedances2i-u2i[i])
}
for (i in 1:length(x3i)){
  threshold.exceedances3i = retsub1[,4][retsub1[,4]>u3i[i]]
  x3i[i] = mean(threshold.exceedances3i-u3i[i])
}
for (i in 1:length(x4i)){
  threshold.exceedances4i = retsub1[,5][retsub1[,5]>u4i[i]]
  x4i[i] = mean(threshold.exceedances4i-u4i[i])
}
for (i in 1:length(x5i)){
  threshold.exceedances5i = negretsub1[,2][negretsub1[,2]>u5i[i]]
  x5i[i] = mean(threshold.exceedances5i-u5i[i])
}
for (i in 1:length(x6i)){
  threshold.exceedances6i = negretsub1[,3][negretsub1[,3]>u6i[i]]
  x6i[i] = mean(threshold.exceedances6i-u6i[i])
}
for (i in 1:length(x7i)){
  threshold.exceedances7i = negretsub1[,4][negretsub1[,4]>u7i[i]]
  x7i[i] = mean(threshold.exceedances7i-u7i[i])
}
for (i in 1:length(x8i)){
  threshold.exceedances8i = negretsub1[,5][negretsub1[,5]>u8i[i]]
  x8i[i] = mean(threshold.exceedances8i-u8i[i])
}
par(mfrow = c(1,2))
plot(x1i~u1i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.4), col="blue", lty=3, lwd=0.5)

plot(x2i~u2i,type = "l",main = "Mean Residual Life Plot", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,8,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)

plot(x3i~u3i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.7), col="blue", lty=3, lwd=0.5)

plot(x4i~u4i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,15,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)

plot(x5i~u5i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.4), col="blue", lty=3, lwd=0.5)

plot(x6i~u6i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.7), col="blue", lty=3, lwd=0.5)

plot(x7i~u7i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.7), col="blue", lty=3, lwd=0.5)

plot(x8i~u8i,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,14,0.2))
abline(v=(0.8), col="blue", lty=3, lwd=0.5)


ui = matrix(0,nrow = 1,ncol = 8)
ui[] = c(0.8, 0.7, 0.6, 0.6, 0.8, 0.7, 0.8, 0.9)
#ui[] = c(0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2)

exceedances1i = retsub1[,2][retsub1[,2]>ui[1]]; y1i = exceedances1i - ui[1]; k1i = length(y1i)
exceedances2i = retsub1[,3][retsub1[,3]>ui[2]]; y2i = exceedances2i - ui[2]; k2i = length(y2i)
exceedances3i = retsub1[,4][retsub1[,4]>ui[3]]; y3i = exceedances3i - ui[3]; k3i = length(y3i)
exceedances4i = retsub1[,5][retsub1[,5]>ui[4]]; y4i = exceedances4i - ui[4]; k4i = length(y4i)
exceedances5i = negretsub1[,2][negretsub1[,2]>ui[5]]; y5i = exceedances5i - ui[5]; k5i = length(y5i)
exceedances6i = negretsub1[,3][negretsub1[,3]>ui[6]]; y6i = exceedances6i - ui[6]; k6i = length(y6i)
exceedances7i = negretsub1[,4][negretsub1[,4]>ui[7]]; y7i = exceedances7i - ui[7]; k7i = length(y7i)
exceedances8i = negretsub1[,5][negretsub1[,5]>ui[8]]; y8i = exceedances8i - ui[8]; k8i = length(y8i)

hillPlot(x = y1i); abline(v=(35), col="red", lty=3, lwd=0.5); #u=1
legend("topright", c("EUR/GBP - right tail", "u = 1"))

hillPlot(x = y2i); abline(v=(85), col="red", lty=3, lwd=0.5); #u=0.85
legend("topright", c("EUR/JPY - right tail", "u = 0.85"))

hillPlot(x = y3i); abline(v=(230), col="red", lty=3, lwd=0.5); #u=0.7
legend("topright", c("EUR/GBP - right tail", "u = 1"))

hillPlot(x = y4i); abline(v=(110), col="red", lty=3, lwd=0.5); #u=0.7
legend("topright", c("EUR/GBP - right tail", "u = 1"))

hillPlot(x = y5i); abline(v=(75), col="red", lty=3, lwd=0.5); #u=0.6
legend("topright", c("EUR/GBP - right tail", "u = 1"))

hillPlot(x = y6i); abline(v=(150), col="red", lty=3, lwd=0.5); #u=0.7
legend("topright", c("EUR/GBP - right tail", "u = 1"))

hillPlot(x = y7i); abline(v=(150), col="red", lty=3, lwd=0.5); #u=0.9
hillPlot(x = y8i); abline(v=(80), col="red", lty=3, lwd=0.5); #u=0.9



################## SUBPERIOD 2 ####################
u1ii = seq(0,max(retsub2[,2]),0.1); u2ii = seq(0,max(retsub2[,3]),0.1);u3ii = seq(0,max(retsub2[,4]),0.1)
u4ii = seq(0,max(retsub2[,5]),0.1); u5ii = seq(0,max(negretsub2[,2]),0.1); u6ii = seq(0,max(negretsub2[,3]),0.1)
u7ii = seq(0,max(negretsub2[,4]),0.1); u8ii = seq(0,max(negretsub2[,5]),0.1)

x1ii = vector('numeric',length(u1ii)); x2ii = vector('numeric',length(u2ii)); x3ii = vector('numeric',length(u3ii))
x4ii = vector('numeric',length(u4ii)); x5ii = vector('numeric',length(u5ii)); x6ii = vector('numeric',length(u6ii))
x7ii = vector('numeric',length(u7ii)); x8ii = vector('numeric',length(u8ii))

for (i in 1:length(x1ii)){
  threshold.exceedances1ii = retsub2[,2][retsub2[,2]>u1ii[i]]
  x1ii[i] = mean(threshold.exceedances1ii-u1ii[i])
}
for (i in 1:length(x2ii)){
  threshold.exceedances2ii = retsub2[,3][retsub2[,3]>u2ii[i]]
  x2ii[i] = mean(threshold.exceedances2ii-u2ii[i])
}
for (i in 1:length(x3ii)){
  threshold.exceedances3ii = retsub2[,4][retsub2[,4]>u3ii[i]]
  x3ii[i] = mean(threshold.exceedances3ii-u3ii[i])
}
for (i in 1:length(x4ii)){
  threshold.exceedances4ii = retsub2[,5][retsub2[,5]>u4ii[i]]
  x4ii[i] = mean(threshold.exceedances4ii-u4ii[i])
}
for (i in 1:length(x5ii)){
  threshold.exceedances5ii = negretsub2[,2][negretsub2[,2]>u5ii[i]]
  x5ii[i] = mean(threshold.exceedances5ii-u5ii[i])
}
for (i in 1:length(x6ii)){
  threshold.exceedances6ii = negretsub2[,3][negretsub2[,3]>u6ii[i]]
  x6ii[i] = mean(threshold.exceedances6ii-u6ii[i])
}
for (i in 1:length(x7ii)){
  threshold.exceedances7ii = negretsub2[,4][negretsub2[,4]>u7ii[i]]
  x7ii[i] = mean(threshold.exceedances7ii-u7ii[i])
}
for (i in 1:length(x8ii)){
  threshold.exceedances8ii = negretsub2[,5][negretsub2[,5]>u8ii[i]]
  x8ii[i] = mean(threshold.exceedances8ii-u8ii[i])
}

plot(x1ii~u1ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.7), col="blue", lty=3, lwd=0.5)

plot(x2ii~u2ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,8,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)

plot(x3ii~u3ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.7), col="blue", lty=3, lwd=0.5)

plot(x4ii~u4ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,15,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)

plot(x5ii~u5ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)

plot(x6ii~u6ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.7), col="blue", lty=3, lwd=0.5)

plot(x7ii~u7ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.8), col="blue", lty=3, lwd=0.5)

plot(x8ii~u8ii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,14,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)


uii = matrix(0,nrow = 1,ncol = 8)
uii[] = c(0.7, 0.7, 0.7, 0.6, 0.6, 0.7, 0.8, 0.7)
#uii[] = c(0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2)

exceedances1ii = retsub2[,2][retsub2[,2]>uii[1]]; y1ii = exceedances1ii - uii[1]; k1ii = length(y1ii)
exceedances2ii = retsub2[,3][retsub2[,3]>uii[2]]; y2ii = exceedances2ii - uii[2]; k2ii = length(y2ii)
exceedances3ii = retsub2[,4][retsub2[,4]>uii[3]]; y3ii = exceedances3ii - uii[3]; k3ii = length(y3ii)
exceedances4ii = retsub2[,5][retsub2[,5]>uii[4]]; y4ii = exceedances4ii - uii[4]; k4ii = length(y4ii)
exceedances5ii = negretsub2[,2][negretsub2[,2]>uii[5]]; y5ii = exceedances5ii - uii[5]; k5ii = length(y5ii)
exceedances6ii = negretsub2[,3][negretsub2[,3]>uii[6]]; y6ii = exceedances6ii - uii[6]; k6ii = length(y6ii)
exceedances7ii = negretsub2[,4][negretsub2[,4]>uii[7]]; y7ii = exceedances7ii - uii[7]; k7ii = length(y7ii)
exceedances8ii = negretsub2[,5][negretsub2[,5]>uii[8]]; y8ii = exceedances8ii - uii[8]; k8ii = length(y8ii)

hillPlot(x = y1ii); abline(v=(55), col="red", lty=3, lwd=0.5); #u=0.65
legend("topright", c("EUR/GBP - right tail", "u = 1"))
hillPlot(x = y2ii); abline(v=(90), col="red", lty=3, lwd=0.5); #u=0.8
hillPlot(x = y3ii); abline(v=(110), col="red", lty=3, lwd=0.5); #u=0.75
hillPlot(x = y4ii); abline(v=(120), col="red", lty=3, lwd=0.5); #u=0.6
hillPlot(x = y5ii); abline(v=(64), col="red", lty=3, lwd=0.5); #u=0.65
hillPlot(x = y6ii); abline(v=(115), col="red", lty=3, lwd=0.5); #u=0.8
hillPlot(x = y7ii); abline(v=(45), col="red", lty=3, lwd=0.5); #u=0.9
hillPlot(x = y8ii); abline(v=(70), col="red", lty=3, lwd=0.5); #u=0.85

################## SUBPERIOD 3 ####################
u1iii = seq(0,max(retsub3[,2]),0.1); u2iii = seq(0,max(retsub3[,3]),0.1);u3iii = seq(0,max(retsub3[,4]),0.1)
u4iii = seq(0,max(retsub3[,5]),0.1); u5iii = seq(0,max(negretsub3[,2]),0.1); u6iii = seq(0,max(negretsub3[,3]),0.1)
u7iii = seq(0,max(negretsub3[,4]),0.1); u8iii = seq(0,max(negretsub3[,5]),0.1)

x1iii = vector('numeric',length(u1iii)); x2iii = vector('numeric',length(u2iii)); x3iii = vector('numeric',length(u3iii))
x4iii = vector('numeric',length(u4iii)); x5iii = vector('numeric',length(u5iii)); x6iii = vector('numeric',length(u6iii))
x7iii = vector('numeric',length(u7iii)); x8iii = vector('numeric',length(u8iii))

for (i in 1:length(x1iii)){
  threshold.exceedances1iii = retsub3[,2][retsub3[,2]>u1iii[i]]
  x1iii[i] = mean(threshold.exceedances1iii-u1iii[i])
}
for (i in 1:length(x2iii)){
  threshold.exceedances2iii = retsub3[,3][retsub3[,3]>u2iii[i]]
  x2iii[i] = mean(threshold.exceedances2iii-u2iii[i])
}
for (i in 1:length(x3iii)){
  threshold.exceedances3iii = retsub3[,4][retsub3[,4]>u3iii[i]]
  x3iii[i] = mean(threshold.exceedances3iii-u3iii[i])
}
for (i in 1:length(x4iii)){
  threshold.exceedances4iii = retsub3[,5][retsub3[,5]>u4iii[i]]
  x4iii[i] = mean(threshold.exceedances4iii-u4iii[i])
}
for (i in 1:length(x5iii)){
  threshold.exceedances5iii = negretsub3[,2][negretsub3[,2]>u5iii[i]]
  x5iii[i] = mean(threshold.exceedances5iii-u5iii[i])
}
for (i in 1:length(x6iii)){
  threshold.exceedances6iii = negretsub3[,3][negretsub3[,3]>u6iii[i]]
  x6iii[i] = mean(threshold.exceedances6iii-u6iii[i])
}
for (i in 1:length(x7iii)){
  threshold.exceedances7iii = negretsub3[,4][negretsub3[,4]>u7iii[i]]
  x7iii[i] = mean(threshold.exceedances7iii-u7iii[i])
}
for (i in 1:length(x8iii)){
  threshold.exceedances8iii = negretsub3[,5][negretsub3[,5]>u8iii[i]]
  x8iii[i] = mean(threshold.exceedances8iii-u8iii[i])
}

plot(x1iii~u1iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.9), col="blue", lty=3, lwd=0.5)

plot(x2iii~u2iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,8,0.2))
abline(v=(0.5), col="blue", lty=3, lwd=0.5)

plot(x3iii~u3iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,14,0.2))
abline(v=(1), col="blue", lty=3, lwd=0.5)

plot(x4iii~u4iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,15,0.2))
abline(v=(0.8), col="blue", lty=3, lwd=0.5)

plot(x5iii~u5iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.4), col="blue", lty=3, lwd=0.5)

plot(x6iii~u6iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(0.7), col="blue", lty=3, lwd=0.5)

plot(x7iii~u7iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,7,0.2))
abline(v=(1.3), col="blue", lty=3, lwd=0.5)

plot(x8iii~u8iii,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,14,0.2))
abline(v=(0.6), col="blue", lty=3, lwd=0.5)


uiii = matrix(0,nrow = 1,ncol = 8)
uiii[] = c(0.9, 0.5, 1, 0.8, 0.4, 0.7, 1.3, 0.6)
#uiii[] = c(0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2)

exceedances1iii = retsub3[,2][retsub3[,2]>uiii[1]]; y1iii = exceedances1iii - uiii[1]; k1iii = length(y1iii)
exceedances2iii = retsub3[,3][retsub3[,3]>uiii[2]]; y2iii = exceedances2iii - uiii[2]; k2iii = length(y2iii)
exceedances3iii = retsub3[,4][retsub3[,4]>uiii[3]]; y3iii = exceedances3iii - uiii[3]; k3iii = length(y3iii)
exceedances4iii = retsub3[,5][retsub3[,5]>uiii[4]]; y4iii = exceedances4iii - uiii[4]; k4iii = length(y4iii)
exceedances5iii = negretsub3[,2][negretsub3[,2]>uiii[5]]; y5iii = exceedances5iii - uiii[5]; k5iii = length(y5iii)
exceedances6iii = negretsub3[,3][negretsub3[,3]>uiii[6]]; y6iii = exceedances6iii - uiii[6]; k6iii = length(y6iii)
exceedances7iii = negretsub3[,4][negretsub3[,4]>uiii[7]]; y7iii = exceedances7iii - uiii[7]; k7iii = length(y7iii)
exceedances8iii = negretsub3[,5][negretsub3[,5]>uiii[8]]; y8iii = exceedances8iii - uiii[8]; k8iii = length(y8iii)

hillPlot(x = y1iii); abline(v=(95), col="red", lty=3, lwd=0.5); #u=0.65
legend("topright", c("EUR/GBP - right tail", "u = 1"))
hillPlot(x = y2iii); abline(v=(90), col="red", lty=3, lwd=0.5); #u=0.8
hillPlot(x = y3ii); abline(v=(110), col="red", lty=3, lwd=0.5); #u=0.75
hillPlot(x = y4ii); abline(v=(120), col="red", lty=3, lwd=0.5); #u=0.6
hillPlot(x = y5ii); abline(v=(64), col="red", lty=3, lwd=0.5); #u=0.65
hillPlot(x = y6ii); abline(v=(115), col="red", lty=3, lwd=0.5); #u=0.8
hillPlot(x = y7ii); abline(v=(45), col="red", lty=3, lwd=0.5); #u=0.9
hillPlot(x = y8ii); abline(v=(70), col="red", lty=3, lwd=0.5); #u=0.85

###choose number of exceed k where H=2

#EUR/GBP - EUR/JPY
k1i <- bvtcplot(retsub1[,2:3])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub1[,2:3], main = "a) EUR/GBP - EUR/JPY")

#Choosing threshold for each fo the two series to be used in biv GPD  model based on half of k1
thresh1i <- apply(retsub1[,2:3], 2, sort, decreasing = TRUE)[(k1i)/2,]

#EUR/GBP - EUR/TRY
k2i <- bvtcplot(retsub1[,c(2,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub1[,c(2,4)], main = "b) EUR/GBP - EUR/TRY")
thresh2i <- apply(retsub1[,c(2,4)], 2, sort, decreasing = TRUE)[(k2i)/2,]

#EUR/GBP - EUR/USD
k3i <- bvtcplot(retsub1[,c(2,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub1[,c(2,5)], main = "c) EUR/GBP - EUR/USD")
thresh3i <- apply(retsub1[,c(2,5)], 2, sort, decreasing = TRUE)[(k3i)/2,]

#EUR/JPY - EUR/TRY
k4i <- bvtcplot(retsub1[,c(3,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub1[,c(3,4)], main = "d) EUR/JPY - EUR/TRY")
thresh4i<- apply(retsub1[,c(3,4)], 2, sort, decreasing = TRUE)[(k4i)/2,]

#EUR/JPY - EUR/USD
k5i <- bvtcplot(retsub1[,c(3,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub1[,c(3,5)], main = "e) EUR/JPY - EUR/USD")
thresh5i <- apply(retsub1[,c(3,5)], 2, sort, decreasing = TRUE)[(k5i)/2,]

#EUR/TRY - EUR/USD
k6i <- bvtcplot(retsub1[,c(4,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub1[,c(4,5)], main = "f) EUR/TRY - EUR/USD")
thresh6i <- apply(retsub1[,c(4,5)], 2, sort, decreasing = TRUE)[(k6i)/2,]

#### DOING THE SAME FOR NEGATIVE SERIES (LEFT TAIL) ####

#EUR/GBP - EUR/JPY left tail
k7i <- bvtcplot(negretsub1[,2:3])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub1[,2:3], main = "a) EUR/GBP - EUR/JPY, left tail")
thresh7i <- apply(negretsub1[,2:3], 2, sort, decreasing = TRUE)[(k7i)/2,]

#EUR/GBP - EUR/TRY left tail
k8i <- bvtcplot(negretsub1[,c(2,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub1[,c(2,4)], main = "b) EUR/GBP - EUR/TRY, left tail")
thresh8i <- apply(negretsub1[,c(2,4)], 2, sort, decreasing = TRUE)[(k8i)/2,]

#EUR/GBP - EUR/USD left tail
k9i <- bvtcplot(negretsub1[,c(2,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub1[,c(2,5)], main = "c) EUR/GBP - EUR/USD, left tail")
thresh9i <- apply(negretsub1[,c(2,5)], 2, sort, decreasing = TRUE)[(k9i)/2,]

#EUR/JPY - EUR/TRY
k10i <- bvtcplot(negretsub1[,c(3,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub1[,c(3,4)], main = "d) EUR/JPY - EUR/TRY, left tail")
thresh10i<- apply(negretsub1[,c(3,4)], 2, sort, decreasing = TRUE)[(k10i)/2,]

#EUR/JPY - EUR/USD
k11i <- bvtcplot(negretsub1[,c(3,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub1[,c(3,5)], main = "e) EUR/JPY - EUR/USD, left tail")
thresh11i <- apply(negretsub1[,c(3,5)], 2, sort, decreasing = TRUE)[(k11i)/2,]

#EUR/TRY - EUR/USD
k12i <- bvtcplot(negretsub1[,c(4,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub1[,c(4,5)], main = "f) EUR/TRY - EUR/USD, left tail")
thresh12i <- apply(negretsub1[,c(4,5)], 2, sort, decreasing = TRUE)[(k12i)/2,]

############ SUBPERIOD 2 #######################

###choose number of exceed k where H=2

#EUR/GBP - EUR/JPY
k1ii <- bvtcplot(retsub2[,2:3])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub2[,2:3], main = "a) EUR/GBP - EUR/JPY")
thresh1ii <- apply(retsub2[,2:3], 2, sort, decreasing = TRUE)[(k1ii)/2,]

#EUR/GBP - EUR/TRY
k2ii <- bvtcplot(retsub2[,c(2,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub2[,c(2,4)], main = "b) EUR/GBP - EUR/TRY")
thresh2ii <- apply(retsub2[,c(2,4)], 2, sort, decreasing = TRUE)[(k2ii)/2,]

#EUR/GBP - EUR/USD
k3ii <- bvtcplot(retsub2[,c(2,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub2[,c(2,5)], main = "c) EUR/GBP - EUR/USD")
thresh3ii <- apply(retsub2[,c(2,5)], 2, sort, decreasing = TRUE)[(k3ii)/2,]

#EUR/JPY - EUR/TRY
k4ii <- bvtcplot(retsub2[,c(3,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub2[,c(3,4)], main = "d) EUR/JPY - EUR/TRY")
thresh4ii<- apply(retsub2[,c(3,4)], 2, sort, decreasing = TRUE)[(k4ii)/2,]

#EUR/JPY - EUR/USD
k5ii <- bvtcplot(retsub2[,c(3,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub2[,c(3,5)], main = "e) EUR/JPY - EUR/USD")
thresh5ii <- apply(retsub2[,c(3,5)], 2, sort, decreasing = TRUE)[(k5ii)/2,]

#EUR/TRY - EUR/USD
k6ii <- bvtcplot(retsub2[,c(4,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub2[,c(4,5)], main = "f) EUR/TRY - EUR/USD")
thresh6ii <- apply(retsub2[,c(4,5)], 2, sort, decreasing = TRUE)[(k6ii)/2,]

#### DOING THE SAME FOR NEGATIVE SERIES (LEFT TAIL) ####

#EUR/GBP - EUR/JPY left tail
k7ii <- bvtcplot(negretsub2[,2:3])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub2[,2:3], main = "a) EUR/GBP - EUR/JPY, left tail")
thresh7ii <- apply(negretsub2[,2:3], 2, sort, decreasing = TRUE)[(k7ii)/2,]

#EUR/GBP - EUR/TRY left tail
k8ii <- bvtcplot(negretsub2[,c(2,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub2[,c(2,4)], main = "b) EUR/GBP - EUR/TRY, left tail")
thresh8ii <- apply(negretsub2[,c(2,4)], 2, sort, decreasing = TRUE)[(k8ii)/2,]

#EUR/GBP - EUR/USD left tail
k9ii <- bvtcplot(negretsub2[,c(2,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub2[,c(2,5)], main = "c) EUR/GBP - EUR/USD, left tail")
thresh9ii <- apply(negretsub2[,c(2,5)], 2, sort, decreasing = TRUE)[(k9ii)/2,]

#EUR/JPY - EUR/TRY
k10ii <- bvtcplot(negretsub2[,c(3,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub2[,c(3,4)], main = "d) EUR/JPY - EUR/TRY, left tail")
thresh10ii<- apply(negretsub2[,c(3,4)], 2, sort, decreasing = TRUE)[(k10ii)/2,]

#EUR/JPY - EUR/USD
k11ii <- bvtcplot(negretsub2[,c(3,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub2[,c(3,5)], main = "e) EUR/JPY - EUR/USD, left tail")
thresh11ii <- apply(negretsub2[,c(3,5)], 2, sort, decreasing = TRUE)[(k11ii)/2,]

#EUR/TRY - EUR/USD
k12ii <- bvtcplot(negretsub2[,c(4,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub2[,c(4,5)], main = "f) EUR/TRY - EUR/USD, left tail")
thresh12ii <- apply(negretsub2[,c(4,5)], 2, sort, decreasing = TRUE)[(k12ii)/2,]

############ SUBPERIOD 3 #######################

###choose number of exceed k where H=2

#EUR/GBP - EUR/JPY
k1iii <- bvtcplot(retsub3[,2:3])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub3[,2:3], main = "a) EUR/GBP - EUR/JPY")
thresh1iii <- apply(retsub3[,2:3], 2, sort, decreasing = TRUE)[(k1iii)/2,]

#EUR/GBP - EUR/TRY
k2iii <- bvtcplot(retsub3[,c(2,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub3[,c(2,4)], main = "b) EUR/GBP - EUR/TRY")
thresh2iii <- apply(retsub3[,c(2,4)], 2, sort, decreasing = TRUE)[(k2iii)/2,]

#EUR/GBP - EUR/USD
k3iii <- bvtcplot(retsub3[,c(2,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub3[,c(2,5)], main = "c) EUR/GBP - EUR/USD")
thresh3iii <- apply(retsub3[,c(2,5)], 2, sort, decreasing = TRUE)[(k3iii)/2,]

#EUR/JPY - EUR/TRY
k4iii <- bvtcplot(retsub3[,c(3,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub3[,c(3,4)], main = "d) EUR/JPY - EUR/TRY")
thresh4iii<- apply(retsub3[,c(3,4)], 2, sort, decreasing = TRUE)[(k4iii)/2,]

#EUR/JPY - EUR/USD
k5iii <- bvtcplot(retsub3[,c(3,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub3[,c(3,5)], main = "e) EUR/JPY - EUR/USD")
thresh5iii <- apply(retsub3[,c(3,5)], 2, sort, decreasing = TRUE)[(k5iii)/2,]

#EUR/TRY - EUR/USD
k6iii <- bvtcplot(retsub3[,c(4,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = retsub3[,c(4,5)], main = "f) EUR/TRY - EUR/USD")
thresh6iii <- apply(retsub3[,c(4,5)], 2, sort, decreasing = TRUE)[(k6iii)/2,]

#### DOING THE SAME FOR NEGATIVE SERIES (LEFT TAIL) ####

#EUR/GBP - EUR/JPY left tail
k7iii <- bvtcplot(negretsub3[,2:3])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub3[,2:3], main = "a) EUR/GBP - EUR/JPY, left tail")
thresh7iii <- apply(negretsub3[,2:3], 2, sort, decreasing = TRUE)[(k7iii)/2,]

#EUR/GBP - EUR/TRY left tail
k8iii <- bvtcplot(negretsub3[,c(2,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub3[,c(2,4)], main = "b) EUR/GBP - EUR/TRY, left tail")
thresh8iii <- apply(negretsub3[,c(2,4)], 2, sort, decreasing = TRUE)[(k8iii)/2,]

#EUR/GBP - EUR/USD left tail
k9iii <- bvtcplot(negretsub3[,c(2,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub3[,c(2,5)], main = "c) EUR/GBP - EUR/USD, left tail")
thresh9iii <- apply(negretsub3[,c(2,5)], 2, sort, decreasing = TRUE)[(k9iii)/2,]

#EUR/JPY - EUR/TRY
k10iii <- bvtcplot(negretsub3[,c(3,4)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub3[,c(3,4)], main = "d) EUR/JPY - EUR/TRY, left tail")
thresh10iii<- apply(negretsub3[,c(3,4)], 2, sort, decreasing = TRUE)[(k10iii)/2,]

#EUR/JPY - EUR/USD
k11iii <- bvtcplot(negretsub3[,c(3,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub3[,c(3,5)], main = "e) EUR/JPY - EUR/USD, left tail")
thresh11iii <- apply(negretsub3[,c(3,5)], 2, sort, decreasing = TRUE)[(k11iii)/2,]

#EUR/TRY - EUR/USD
k12iii <- bvtcplot(negretsub3[,c(4,5)])$k0 #stores the value of k where H=2 in k1
bvtcplot(x = negretsub3[,c(4,5)], main = "f) EUR/TRY - EUR/USD, left tail")
thresh12iii <- apply(negretsub3[,c(4,5)], 2, sort, decreasing = TRUE)[(k12iii)/2,]
#bivariate model estimation through censored MLE.

K = matrix(0,nrow = 3,ncol = 12)
K[1,] = c(k1i,k2i,k3i,k4i,k5i,k6i,k7i,k8i,k9i,k10i,k11i,k12i)
K[2,] = c(k1ii,k2ii,k3ii,k4ii,k5ii,k6ii,k7ii,k8ii,k9ii,k10ii,k11ii,k12ii)
K[3,] = c(k1iii,k2iii,k3iii,k4iii,k5iii,k6iii,k7iii,k8iii,k9iii,k10iii,k11iii,k12iii)

Thres1 = matrix(0,nrow = 2,ncol = 12) 
Thres2 = matrix(0,nrow = 2,ncol = 12) 
Thres3 = matrix(0,nrow = 2,ncol = 12) 
Thres1[,1:12] = c(thresh1i, thresh2i, thresh3i, thresh4i, thresh5i, thresh6i, thresh7i, 
                  thresh8i, thresh9i, thresh10i, thresh11i, thresh12i) 
Thres2[,1:12] = c(thresh1ii, thresh2ii, thresh3ii, thresh4ii, thresh5ii, thresh6ii, thresh7ii, 
                  thresh8ii, thresh9ii, thresh10ii, thresh11ii, thresh12ii) 
Thres3[,1:12] = c(thresh1iii, thresh2iii, thresh3iii, thresh4iii, thresh5iii, thresh6iii, thresh7iii, 
                  thresh8iii, thresh9iii, thresh10iii, thresh11iii, thresh12iii) 

############################# MLE ESTIMATION OF BIV EVT MODELS + PLOTS #################################


############# SUBPERIOD 1 ############
par(mfrow=c(1,1))
m1i = fitbvgpd(data = retsub1[,2:3],threshold = ui[1:2],model = "log"); m1i; m1i$chi #1. GBP � JPY
plot(m1i,which = 1, p = c(0.95, 0.975, 0.99), ask = F)
#pickands plot: horizontal line is independence, other 2 perfect dependence
chiplot(data = retsub1[,2:3],which = c(1,2),ask = F)
taildep(x = retsub1[,2:3], u = 0.99,type = "chibar")
taildep.test(x = retsub1[,2:3], cthresh = -0.4)
#independence
m2i = fitbvgpd(data = retsub1[,c(2,4)],threshold = ui[c(1,3)],model = "log");  m2i ; m2i$chi #2.	GBP � TRY
plot(m2i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(2,4)],which = c(1,2),ask = F)
#independence 
m3i = fitbvgpd(data = retsub1[,c(2,5)],threshold = ui[c(1,4)],model = "log"); m3i; m3i$chi #3.	GBP � USD
plot(m3i,which = 1, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(2,5)],which = c(1,2),ask = F)
#independence
m4i = fitbvgpd(data = retsub1[,c(3,4)],threshold = ui[c(2,3)],model = "log"); m4i; m4i$chi# 4.	JPY � TRY
plot(m4i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(3,4)],which = c(1,2),ask = F)
#independence
m5i = fitbvgpd(data = retsub1[,c(3,5)],threshold = ui[c(2,4)],model = "log"); m5i; m5i$chi# 5.	JPY � USD
plot(m5i,which = 1, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(3,5)],which = c(1,2),ask = F)
#independence
m6i = fitbvgpd(data = retsub1[,c(4,5)],threshold = ui[c(3,4)],model = "log"); m6i; m6i$chi# 6.	TRY � USD
plot(m6i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(4,5)],which = c(1,2),ask = F)
#independence
m7i = fitbvgpd(data = negretsub1[,2:3],threshold = ui[c(5,6)],model = "log"); m7i; m7i$chi #1. GBP � JPY
plot(m7i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub1[,c(2,3)],which = c(1,2),ask = F)
#independence
m8i = fitbvgpd(data = negretsub1[,c(2,4)],threshold = ui[c(5,7)],model = "log");  m8i ; m8i$chi #2.	GBP � TRY
plot(m8i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub1[,c(2,4)],which = c(1,2),ask = F)
#independence
m9i = fitbvgpd(data = negretsub1[,c(2,5)],threshold = ui[c(5,8)],model = "log"); m9i; m9i$chi #3.	GBP � USD
plot(m9i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub1[,c(2,5)],which = c(1,2),ask = F)
#independence
m10i = fitbvgpd(data = negretsub1[,c(3,4)],threshold = ui[c(6,7)],model = "log"); m10i; m10i$chi# 4.	JPY � TRY
plot(m10i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub1[,c(3,4)],which = c(1,2),ask = F)
#independence
m11i = fitbvgpd(data = negretsub1[,c(3,5)],threshold = ui[c(6,8)],model = "log"); m11i; m11i$chi# 5.	JPY � USD
plot(m11i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(3,5)],which = c(1,2),ask = F)
#independence
m12i = fitbvgpd(data = negretsub1[,c(4,5)],threshold = ui[c(7,8)],model = "log"); m12i; m12i$chi# 6.	TRY � USD
plot(m12i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(4,5)],which = c(1,2),ask = F)
#independence
############### SUBPERIOD 2 ##############

m1ii = fitbvgpd(data = retsub2[,2:3],threshold = uii[c(1,2)],model = "log"); m1ii; m1ii$chi #1. GBP � JPY
plot(m1ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub2[,c(2,3)],which = c(1,2),ask = F)
#independence
m2ii = fitbvgpd(data = retsub2[,c(2,4)],threshold = uii[c(1,3)],model = "log");  m2ii ; m2ii$chi #2.	GBP � TRY
plot(m2ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub2[,c(2,4)],which = c(1,2),ask = F)
#independence
m3ii = fitbvgpd(data = retsub2[,c(2,5)],threshold = uii[c(1,4)],model = "log"); m3ii; m3ii$chi #3.	GBP � USD
plot(m3ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub2[,c(2,5)],which = c(1,2),ask = F)
#independence
m4ii = fitbvgpd(data = retsub2[,c(3,4)],threshold = uii[c(2,3)],model = "log"); m4ii; m4ii$chi# 4.	JPY � TRY
plot(m2i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(2,4)],which = c(1,2),ask = F)
#independence
m5ii = fitbvgpd(data = retsub2[,c(3,5)],threshold = uii[c(2,4)],model = "log"); m5ii; m5ii$chi# 5.	JPY � USD
plot(m5ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub2[,c(3,5)],which = c(1,2),ask = F)
#independence
m6ii = fitbvgpd(data = retsub2[,c(4,5)],threshold = uii[c(3,4)],model = "log"); m6ii; m6ii$chi# 6.	TRY � USD
plot(m6ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub2[,c(4,5)],which = c(1,2),ask = F)
#independence
m7ii = fitbvgpd(data = negretsub2[,2:3],threshold = uii[c(5,6)],model = "log"); m7ii; m7ii$chi #1. GBP � JPY
plot(m7ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(2,3)],which = c(1,2),ask = F)
taildep(x = negretsub2[,2:3], u = 0.99, type = "chibar")
taildep.test(x = negretsub2[,2:3], cthresh = -0.35)
#indep
m8ii = fitbvgpd(data = negretsub2[,c(2,4)],threshold = uii[c(5,7)],model = "log");  m8ii ; m8ii$chi #2.	GBP � TRY
plot(m8ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(2,4)],which = c(1,2),ask = F)
taildep(x = negretsub2[,c(2,4)], u = 0.99)
taildep.test(x = negretsub2[,c(2,4)], cthresh = -0.4)
#indep.
m9ii = fitbvgpd(data = negretsub2[,c(2,5)],threshold = uii[c(5,8)],model = "log"); m9ii; m9ii$chi #3.	GBP � USD
plot(m9ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(2,5)],which = c(1,2),ask = F)
taildep.test(x = negretsub2[,c(2,5)], cthresh = -0.35)
#indep
m10ii = fitbvgpd(data = negretsub2[,c(3,4)],threshold = uii[c(6,7)],model = "log"); m10ii; m10ii$chi# 4.	JPY � TRY
plot(m10ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(3,4)],which = c(1,2),ask = F)
#DEPENDENCE
m11ii = fitbvgpd(data = negretsub2[,c(3,5)],threshold = uii[c(6,8)],model = "log"); m11ii; m11ii$chi# 5.	JPY � USD
plot(m11ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(3,5)],which = c(1,2),ask = F)
#independence
m12ii = fitbvgpd(data = negretsub2[,c(4,5)],threshold = uii[c(7,8)],model = "log"); m12ii; m12ii$chi# 6.	TRY � USD
plot(m12ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(4,5)],which = c(1,2),ask = F)
taildep.test(x = negretsub2[,c(4,5)], cthresh = -0.4)
#indep
############### SUBPERIOD 3 ##############

m1iii = fitbvgpd(data = retsub3[,2:3],threshold = uiii[c(1,2)],model = "log"); m1iii; m1iii$chi #1. GBP � JPY
plot(m1iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(2,3)],which = c(1,2),ask = F)
#independence
m2iii = fitbvgpd(data = retsub3[,c(2,4)],threshold = uiii[c(1,3)],model = "log");  m2iii ; m2iii$chi #2.	GBP � TRY
plot(m2iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(2,4)],which = c(1,2),ask = F)
#independence
m3iii = fitbvgpd(data = retsub3[,c(2,5)],threshold = uiii[c(1,4)],model = "log"); m3iii; m3iii$chi #3.	GBP � USD
plot(m3iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(2,5)],which = c(1,2),ask = F)
#independence
m4iii = fitbvgpd(data = retsub3[,c(3,4)],threshold = uiii[c(2,3)],model = "log"); m4iii; m4iii$chi# 4.	JPY � TRY
plot(m4iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(3,4)],which = c(1,2),ask = F)
#ind
m5iii = fitbvgpd(data = retsub3[,c(3,5)],threshold = uiii[c(2,4)],model = "log"); m5iii; m5iii$chi# 5.	JPY � USD
plot(m5iii,which = 1, p = c(0.95, 0.975, 0.99), ask = F)
par(mfrow = c(1,2))
chiplot(data = retsub3[,c(3,5)],which = c(1,2),ask = F)
taildep.test(x = retsub3[,c(3,5)], cthresh = -0.4)
#DEPENDENCE
m6iii = fitbvgpd(data = retsub3[,c(4,5)],threshold = uiii[c(3,4)],model = "log"); m6iii; m6iii$chi# 6.	TRY � USD
plot(m6iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(4,5)],which = c(1,2),ask = F)
#ind
m7iii = fitbvgpd(data = negretsub3[,2:3],threshold = uiii[c(5,6)],model = "log"); m7iii; m7iii$chi #1. GBP � JPY
plot(m7iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(2,3)],which = c(1,2),ask = F)
#ind
m8iii = fitbvgpd(data = negretsub3[,c(2,4)],threshold = uiii[c(5,7)],model = "log");  m8iii ; m8iii$chi #2.	GBP � TRY
plot(m8iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(2,4)],which = c(1,2),ask = F)
#ind
m9iii = fitbvgpd(data = negretsub3[,c(2,5)],threshold = uiii[c(5,8)],model = "log"); m9iii; m9iii$chi #3.	GBP � USD
plot(m9iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(2,5)],which = c(1,2),ask = F)
#ind
m10iii = fitbvgpd(data = negretsub3[,c(3,4)],threshold = uiii[c(6,7)],model = "log"); m10iii; m10iii$chi# 4.	JPY � TRY
plot(m10iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(3,4)],which = c(1,2),ask = F)
#ind
m11iii = fitbvgpd(data = negretsub3[,c(3,5)],threshold = uiii[c(6,8)],model = "log"); m11iii; m11iii$chi# 5.	JPY � USD
plot(m11iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(3,5)],which = c(1,2),ask = F)
taildep.test(x = negretsub3[,c(3,5)], cthresh = -0.4)
#indep
m12iii = fitbvgpd(data = negretsub3[,c(4,5)],threshold = uiii[c(7,8)],model = "log"); m12iii; m12iii$chi# 6.	TRY � USD
plot(m12iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(4,5)],which = c(1,2),ask = F)
#ind
############# SUBPERIOD 1 ############
par(mfrow=c(1,2))
m1i = fitbvgpd(data = retsub1[,2:3],threshold = thresh1i,model = "log"); m1i; m1i$chi #1. GBP � JPY
plot(m1i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
#pickands plot: horizontal line is independence, other 2 perfect dependence
chiplot(data = retsub1[,2:3],which = c(1,2),ask = F)
thresh1i
m2i = fitbvgpd(data = retsub1[,c(2,4)],threshold = thresh2i,model = "log");  m2i ; m2i$chi #2.	GBP � TRY
plot(m2i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(2,4)],which = c(1,2),ask = F)

m3i = fitbvgpd(data = retsub1[,c(2,5)],threshold = thresh3i,model = "log"); m3i; m3i$chi #3.	GBP � USD
plot(m3i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(2,5)],which = c(1,2),ask = F)

m4i = fitbvgpd(data = retsub1[,c(3,4)],threshold = thresh4i,model = "log"); m4i; m4i$chi# 4.	JPY � TRY
plot(m4i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(3,4)],which = c(1,2),ask = F)

m5i = fitbvgpd(data = retsub1[,c(3,5)],threshold = thresh5i,model = "log"); m5i; m5i$chi# 5.	JPY � USD
plot(m5i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(3,5)],which = c(1,2),ask = F)

m6i = fitbvgpd(data = retsub1[,c(4,5)],threshold = thresh6i,model = "log"); m6i; m6i$chi# 6.	TRY � USD
plot(m6i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(4,5)],which = c(1,2),ask = F)

m7i = fitbvgpd(data = negretsub1[,2:3],threshold = thresh7i,model = "log"); m7i; m7i$chi #1. GBP � JPY
plot(m7i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub1[,c(2,3)],which = c(1,2),ask = F)

m8i = fitbvgpd(data = negretsub1[,c(2,4)],threshold = thresh8i,model = "log");  m8i ; m8i$chi #2.	GBP � TRY
plot(m8i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub1[,c(2,4)],which = c(1,2),ask = F)

m9i = fitbvgpd(data = negretsub1[,c(2,5)],threshold = thresh9i,model = "log"); m9i; m9i$chi #3.	GBP � USD
plot(m9i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub1[,c(2,5)],which = c(1,2),ask = F)

m10i = fitbvgpd(data = negretsub1[,c(3,4)],threshold = thresh10i,model = "log"); m10i; m10i$chi# 4.	JPY � TRY
plot(m10i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub1[,c(3,4)],which = c(1,2),ask = F)

m11i = fitbvgpd(data = negretsub1[,c(3,5)],threshold = thresh11i,model = "log"); m11i; m11i$chi# 5.	JPY � USD
plot(m11i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(3,5)],which = c(1,2),ask = F)

m12i = fitbvgpd(data = negretsub1[,c(4,5)],threshold = thresh12i,model = "log"); m12i; m12i$chi# 6.	TRY � USD
plot(m12i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(4,5)],which = c(1,2),ask = F)

############### SUBPERIOD 2 ##############

m1ii = fitbvgpd(data = retsub2[,2:3],threshold = thresh1ii,model = "log"); m1ii; m1ii$chi #1. GBP � JPY
plot(m1ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub2[,c(2,3)],which = c(1,2),ask = F)

m2ii = fitbvgpd(data = retsub2[,c(2,4)],threshold = thresh2ii,model = "log");  m2ii ; m2ii$chi #2.	GBP � TRY
plot(m2ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub2[,c(2,4)],which = c(1,2),ask = F)

m3ii = fitbvgpd(data = retsub2[,c(2,5)],threshold = thresh3ii,model = "log"); m3ii; m3ii$chi #3.	GBP � USD
plot(m3ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub2[,c(2,5)],which = c(1,2),ask = F)

m4ii = fitbvgpd(data = retsub2[,c(3,4)],threshold = thresh4ii,model = "log"); m4ii; m4ii$chi# 4.	JPY � TRY
plot(m2i,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub1[,c(2,4)],which = c(1,2),ask = F)

m5ii = fitbvgpd(data = retsub2[,c(3,5)],threshold = thresh5ii,model = "log"); m5ii; m5ii$chi# 5.	JPY � USD
plot(m5ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub2[,c(3,5)],which = c(1,2),ask = F)

m6ii = fitbvgpd(data = retsub2[,c(4,5)],threshold = thresh6ii,model = "log"); m6ii; m6ii$chi# 6.	TRY � USD
plot(m6ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub2[,c(4,5)],which = c(1,2),ask = F)

m7ii = fitbvgpd(data = negretsub2[,2:3],threshold = thresh7ii,model = "log"); m7ii; m7ii$chi #1. GBP � JPY
plot(m7ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(2,3)],which = c(1,2),ask = F)

m8ii = fitbvgpd(data = negretsub2[,c(2,4)],threshold = thresh8ii,model = "log");  m8ii ; m8ii$chi #2.	GBP � TRY
plot(m8ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(2,4)],which = c(1,2),ask = F)

m9ii = fitbvgpd(data = negretsub2[,c(2,5)],threshold = thresh9ii,model = "log"); m9ii; m9ii$chi #3.	GBP � USD
plot(m9ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(2,5)],which = c(1,2),ask = F)

m10ii = fitbvgpd(data = negretsub2[,c(3,4)],threshold = thresh10ii,model = "log"); m10ii; m10ii$chi# 4.	JPY � TRY
plot(m10ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(3,4)],which = c(1,2),ask = F)

m11ii = fitbvgpd(data = negretsub2[,c(3,5)],threshold = thresh11ii,model = "log"); m11ii; m11ii$chi# 5.	JPY � USD
plot(m11ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(3,5)],which = c(1,2),ask = F)

m12ii = fitbvgpd(data = negretsub2[,c(4,5)],threshold = thresh12ii,model = "log"); m12ii; m12ii$chi# 6.	TRY � USD
plot(m12ii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub2[,c(4,5)],which = c(1,2),ask = F)

############### SUBPERIOD 3 ##############

m1iii = fitbvgpd(data = retsub3[,2:3],threshold = thresh1iii,model = "log"); m1iii; m1iii$chi #1. GBP � JPY
plot(m1iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(2,3)],which = c(1,2),ask = F)

m2iii = fitbvgpd(data = retsub3[,c(2,4)],threshold = thresh2iii,model = "log");  m2iii ; m2iii$chi #2.	GBP � TRY
plot(m2iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(2,4)],which = c(1,2),ask = F)

m3iii = fitbvgpd(data = retsub3[,c(2,5)],threshold = thresh3iii,model = "log"); m3iii; m3iii$chi #3.	GBP � USD
plot(m3iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(2,5)],which = c(1,2),ask = F)

m4iii = fitbvgpd(data = retsub3[,c(3,4)],threshold = thresh4iii,model = "log"); m4iii; m4iii$chi# 4.	JPY � TRY
plot(m4iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(3,4)],which = c(1,2),ask = F)

m5iii = fitbvgpd(data = retsub3[,c(3,5)],threshold = thresh5iii,model = "log"); m5iii; m5iii$chi# 5.	JPY � USD
plot(m5iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(3,5)],which = c(1,2),ask = F)

m6iii = fitbvgpd(data = retsub3[,c(4,5)],threshold = thresh6iii,model = "log"); m6iii; m6iii$chi# 6.	TRY � USD
plot(m6iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = retsub3[,c(4,5)],which = c(1,2),ask = F)

m7iii = fitbvgpd(data = negretsub3[,2:3],threshold = thresh7iii,model = "log"); m7iii; m7iii$chi #1. GBP � JPY
plot(m7iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(2,3)],which = c(1,2),ask = F)

m8iii = fitbvgpd(data = negretsub3[,c(2,4)],threshold = thresh8iii,model = "log");  m8iii ; m8iii$chi #2.	GBP � TRY
plot(m8iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(2,4)],which = c(1,2),ask = F)

m9iii = fitbvgpd(data = negretsub3[,c(2,5)],threshold = thresh9iii,model = "log"); m9iii; m9iii$chi #3.	GBP � USD
plot(m9iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(2,5)],which = c(1,2),ask = F)

m10iii = fitbvgpd(data = negretsub3[,c(3,4)],threshold = thresh10iii,model = "log"); m10iii; m10iii$chi# 4.	JPY � TRY
plot(m10iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(3,4)],which = c(1,2),ask = F)

m11iii = fitbvgpd(data = negretsub3[,c(3,5)],threshold = thresh11iii,model = "log"); m11iii; m11iii$chi# 5.	JPY � USD
plot(m11iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(3,5)],which = c(1,2),ask = F)

m12iii = fitbvgpd(data = negretsub3[,c(4,5)],threshold = thresh12iii,model = "log"); m12iii; m12iii$chi# 6.	TRY � USD
plot(m12iii,which = 1:2, p = c(0.95, 0.975, 0.99), ask = F)
chiplot(data = negretsub3[,c(4,5)],which = c(1,2),ask = F)
chimeas(data = negretsub3[,c(4,5)])



