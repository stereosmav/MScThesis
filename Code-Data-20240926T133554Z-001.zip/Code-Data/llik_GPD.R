llik_GPD <- function(theta,y){
  
  k = length(y)
  sigma = theta[1]
  ksi=theta[2]
  
  m = min(1 + (ksi * y)/sigma)
  if(m<0.00001)return(as.double(1000000)) 
  if(sigma<0.00001)return(as.double(1000000))
  
    if (ksi == 0){
      l = -k * log(sigma) - (1/sigma) * sum(y)
    }
    else{
      l = -k * log(sigma) - (1 + (1/ksi)) * sum(log(1 + (ksi * y)/sigma))
    }
    
  # mean log likelihood
  return(-l)
  
  
}
