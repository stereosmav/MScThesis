######## PACKAGES ###########

library(ggplot2)
library(ggpubr)
library(tseries)
library(moments)
library(ismev)
library(fExtremes)
library(forecast)
library(rugarch)
library(MTS)

################## IMPORTING DATA ###################

returns = read.csv(file = "exch_rate_returns.csv",header = T,sep = ",",dec = ".")
returns = returns[,2:6]

neg_returns = read.csv(file = "exch_rate_neg_returns.csv",header = T,sep = ",",dec = ".")

##################### EXAMINING WHICH ARMA MODEL IS MOST APPROPRIATE FOR RETURNS ###################

#The p,d, and q are then chosen by minimizing the AICc. The algorithm uses 
#a stepwise search to traverse the model space to select the best model with smallest AICc.
auto.arima(y = returns$EURGBP,trace = T) #(0,0,0)
auto.arima(y = returns$EURJPY,trace = T) #(0,0,1)
auto.arima(y = returns$EURTRY,trace = T) #(2,0,2)
auto.arima(y = returns$EURUSD,trace = T) #(0,0,2)

#same results for neg returns
auto.arima(y = neg_returns$EURGBP,trace = T) #(0,0,0)
auto.arima(y = neg_returns$EURJPY,trace = T) #(0,0,1)
auto.arima(y = neg_returns$EURTRY,trace = T) #(2,0,2)
auto.arima(y = neg_returns$EURUSD,trace = T) #(0,0,2)


##################### fitting arma model & determining whether heteroskedasticity exists #############################

#1 GBP

armodel1<-arima(returns$EURGBP, order = c(1,0,1),include.mean = FALSE)
summary(armodel1)
residuals1<-residuals(armodel1)
residfit1<-returns$EURGBP-residuals1
ts.plot(returns$EURGBP)
points(residfit1, col="red")

#arch test
#taking standardized residuals
archTest(residuals1,lag = 1)#Ljung-Box statistics (Q)
#p-value 0 so null hypothesis rejected-> heteroskedasticity exists in the residuals GARCH model can be used.

#2 JPY

armodel2<-arima(returns$EURJPY, order = c(1,0,1),include.mean = FALSE)
summary(armodel2)
residuals2<-residuals(armodel2)
residfit2<-returns$EURJPY-residuals2
ts.plot(returns$EURJPY)
points(residfit2, col="red")

#arch test
#taking standardized residuals
archTest(residuals2,)#Ljung-Box statistics (Q)
#significant p-val so heteroskedasticity

#3 TRY

armodel3<-arima(returns$EURTRY, order = c(2,0,2),include.mean = FALSE)
summary(armodel2)
residuals3<-residuals(armodel3)

#arch test
#taking standardized residuals
archTest(residuals3,lag = 1)#Ljung-Box statistics (Q)
#heteroskedasticity

#4 USD

armodel4<-arima(returns$EURUSD, order = c(0,0,2),include.mean = FALSE)
summary(armodel4)
residuals4<-residuals(armodel4)

#arch test
#taking standardized residuals
archTest(residuals4,lag = 1)#Ljung-Box statistics (Q)
#heteroskedasticity

#same results for negative returns

############################# FITTING GARCH MODELS ##################################

#1 GBP
spec1<-ugarchspec(mean.model = list(armaOrder=c(0,0)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                  distribution.model = "std")
garchmod1<-ugarchfit(spec1,data = returns$EURGBP)
garchmod1
residgarch1<-residuals(garchmod1, standardize =T)
residgarch1<-(returns$EURGBP - uncmean(garchmod1))/sigma(garchmod1)
unc
#mu and omega = intercept terms
#a1(ut-1^2) and b1(sigmat-1^2) coeff stat sign and positive
#a1+b1=0.90+0.087=0.98 very close to 1
#which means persistent shocks to the cond variance

plot(garchmod1,which=3)#returns are symbolized by the light color and sd by dark
plot(garchmod1,which=9)#QQ-plot of resid
plot(garchmod1,which=10) #no A/C
plot(garchmod1,which=8)#pos outliers

#2 JPY
spec2<-ugarchspec(mean.model = list(armaOrder=c(0,1)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                  distribution.model = "std")
garchmod2<-ugarchfit(spec2,data = returns$EURJPY)
garchmod2
residgarch2<-residuals(garchmod2)
residgarch2<- (returns$EURJPY - uncmean(garchmod2))/sigma(garchmod2)

plot(garchmod2,which=8)#pos outliers

#3 TRY
spec3<-ugarchspec(mean.model = list(armaOrder=c(2,2)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                  distribution.model = "std")
garchmod3<-ugarchfit(spec3,data = returns$EURTRY)
garchmod3
residgarch3<-residuals(garchmod3)
residgarch3<- (returns$EURTRY - uncmean(garchmod3))/sigma(garchmod3)
uncmean
plot(garchmod3,which=8)#pos outliers

#4 USD
spec4<-ugarchspec(mean.model = list(armaOrder=c(0,2)),variance.model = list(garchOrder=c(1,1),model="gjrGARCH"),
                  distribution.model = "std")
garchmod4<-ugarchfit(spec4,data = returns$EURUSD)
garchmod4
residgarch4<-residuals(garchmod4)
residgarch4<- (returns$EURUSD - uncmean(garchmod4))/sigma(garchmod4)

plot(garchmod4,which=8)#pos outliers#fat tails

#creating matrices for pos and neg residuals
garchresid = matrix(0,nrow = 4187,ncol = 4)
neggarchresid = matrix(0,nrow = 4187,ncol = 4)
garchresid[,1] = residgarch1; garchresid[,2] = residgarch2; garchresid[,3] = residgarch3; garchresid[,4] = residgarch4
neggarchresid[,1] = -residgarch1; neggarchresid[,2] = -residgarch2; neggarchresid[,3] = -residgarch3; neggarchresid[,4] = -residgarch4
garchresid = as.data.frame(garchresid)
neggarchresid = as.data.frame(neggarchresid)

################################ APPLYING UNIV EVT ON GARCH MODEL RESIDUALS #################################


#plotting mean resid life plot for EUR/GBP to determine threshold u.
#creating vector of possible thresholds:
u1 = seq(0,max(garchresid[,1]),0.1)
u2 = seq(0,max(garchresid[,2]),0.1)
u3 = seq(0,max(garchresid[,3]),0.1)
u4 = seq(0,max(garchresid[,4]),0.1)

u5 = seq(0,max(neggarchresid[,1]),0.1)
u6 = seq(0,max(neggarchresid[,2]),0.1)
u7 = seq(0,max(neggarchresid[,3]),0.1)
u8 = seq(0,max(neggarchresid[,4]),0.1)


x1 = vector('numeric',length(u1))
x2 = vector('numeric',length(u2))
x3 = vector('numeric',length(u3))
x4 = vector('numeric',length(u4))

x5 = vector('numeric',length(u5))
x6 = vector('numeric',length(u6))
x7 = vector('numeric',length(u7))
x8 = vector('numeric',length(u8))

#mean excess of data for each value of u:

#positive

for (i in 1:length(x1)){
  threshold.exceedances1 = garchresid$V1[garchresid$V1>u1[i]]
  x1[i] = mean(threshold.exceedances1-u1[i])
}
for (i in 1:length(x2)){
  threshold.exceedances2 = garchresid$V2[garchresid$V2>u2[i]]
  x2[i] = mean(threshold.exceedances2-u2[i])
}
for (i in 1:length(x3)){
  threshold.exceedances3 = garchresid$V3[garchresid$V3>u3[i]]
  x3[i] = mean(threshold.exceedances3-u3[i])
}
for (i in 1:length(x4)){
  threshold.exceedances4 = garchresid$V4[garchresid$V4>u4[i]]
  x4[i] = mean(threshold.exceedances4-u4[i])
}

#negative

for (i in 1:length(x5)){
  threshold.exceedances5 = neggarchresid$V1[neggarchresid$V1>u5[i]]
  x5[i] = mean(threshold.exceedances5-u5[i])
}
for (i in 1:length(x6)){
  threshold.exceedances6 = neggarchresid$V2[neggarchresid$V2>u6[i]]
  x6[i] = mean(threshold.exceedances6-u6[i])
}
for (i in 1:length(x7)){
  threshold.exceedances7 = neggarchresid$V3[neggarchresid$V3>u7[i]]
  x7[i] = mean(threshold.exceedances7-u7[i])
}
for (i in 1:length(x8)){
  threshold.exceedances8 = neggarchresid$V4[neggarchresid$V4>u8[i]]
  x8[i] = mean(threshold.exceedances8-u8[i])
}

#mrl plot

#positive:
par(mfrow = c(1,1))
plot(x1~u1,type = "l",main = "Mean Residual Life Plot: EUR/GBP - right tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,10,0.2))
abline(v=(1.4), col="blue", lty=3, lwd=0.5)
#u1=0.8
plot(x2~u2,type = "l",main = "Mean Residual Life Plot: EUR/JPY - right  tail", ylab = "mean excess",
     xlab = "threshold u", xaxt="none", frame.plot = F)
axis(1, seq(0,8,0.2))
abline(v=(1.2), col="blue", lty=3, lwd=0.5)#1.1
#u2 =1.4
plot(x3~u3,type = "l",main = "Mean Residual Life Plot: EUR/TRY - right tail", ylab = "mean excess",
     xlab = "threhsold u", xaxt="none",frame.plot = F, xlim = c(0,8))
axis(1, seq(0,8,0.5))
abline(v=(1.5), col="blue", lty=3, lwd=0.5)
#u3=2.1
plot(x4~u4,type = "l",main = "Mean Residual Life Plot: EUR/USD - right tail", ylab = "mean excess",
     xlab = "threshold u", xaxt="none", frame.plot = F,xlim = c(0,8))
axis(1, seq(0,8,0.2))
abline(v=(1.4), col="blue", lty=3, lwd=0.5)
#u4 = 1

#negative:

plot(x5~u5,type = "l",main = "Mean Residual Life Plot: EUR/GBP - left tail", ylab = "mean excess",
     xlab = "threshold u" ,xaxt="none", frame.plot = F)
axis(1, seq(0,4,0.2))
abline(v=(1.1), col="blue", lty=3, lwd=0.5)
#u5=0.8
plot(x6~u6,type = "l",main = "Mean Residual Life Plot: EUR/JPY - left tail", ylab = "mean excess",
     xlab = "threshold u", xaxt="none", frame.plot = F)
axis(1, seq(0,10,0.2))
abline(v=(1.5), col="blue", lty=3, lwd=0.5)
#u6 = 0.75
plot(x7~u7,type = "l",main = "Mean Residual Life Plot : EUR/TRY - left tail", ylab = "mean excess",
     xlab = "threshold u", xaxt="none", frame.plot = F, xlim = c(0,6))
axis(1, seq(0,6,0.2))
abline(v=(1.2), col="blue", lty=3, lwd=0.5)
#u7=1.7
plot(x8~u8,type = "l",main = "Mean Residual Life Plot: EUR/USD - left tail", ylab = "mean excess",
     xlab = "threshold u", xaxt="none", frame.plot = F)
axis(1, seq(0,13,0.5))
abline(v=(1.6), col="blue", lty=3, lwd=0.5)
#u8 = 0.75

#create matrix for thresholds
u = matrix(0,nrow = 1,ncol = 8)
colnames(x = u) = c('EUR/GBP','EUR/JPY','EUR/TRY','EUR/USD','neg EUR/GBP','neg EUR/JPY','neg EUR/TRY','neg EUR/USD')
u[] = c(1.5, 1.5, 1.5, 1.4, 1.3, 1.7, 1.2, 1.6)
#u[] = c(0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5)
exceedances1 = garchresid$V1[garchresid$V1>u[1]]
y1 = exceedances1 - u[1]
k1 = length(y1)

exceedances2 = garchresid$V2[garchresid$V2>u[2]]
y2 = exceedances2 - u[2]
k2 = length(y2)

exceedances3 = garchresid$V3[garchresid$V3>u[3]]
y3 = exceedances3 - u[3]
k3 = length(y3)

exceedances4 = garchresid$V4[garchresid$V4>u[4]]
y4 = exceedances4 - u[4]
k4 = length(y4)

#negative:
exceedances5 = neggarchresid$V1[neggarchresid$V1>u[5]]
y5 = exceedances5 - u[5]
k5 = length(y5)

exceedances6 = neggarchresid$V2[neggarchresid$V2>u[6]]
y6 = exceedances6 - u[6]
k6 = length(y6)

exceedances7 = neggarchresid$V3[neggarchresid$V3>u[7]]
y7 = exceedances7 - u[7]
k7 = length(y7)

exceedances8 = neggarchresid$V4[neggarchresid$V4>u[8]]
y8 = exceedances8 - u[8]
k8 = length(y8)

####################################HILL ESTIMATOR GRAPHS FOR THRESHOLD CHOICE #################
par(mfrow = c(2,2))

hillPlot(x = y1,ci = 0.95)
abline(v=(95), col="red", lty=3, lwd=0.5)
legend("topright", c("EUR/GBP - right tail", "u = 1.8"))
#u1 = 1.05

hillPlot(x = y2,ci = 0.95)
abline(v=(70), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/JPY - right tail", "u = 1.8"))
#u2 = 0.95

hillPlot(x = y3,ci = 0.95)
abline(v=(120), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/TRY - right tail", "u = 1.5"))

hillPlot(x = y4,ci = 0.95)
abline(v=(120), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/USD - right tail", "u = 1.4"))

hillPlot(x = y5,ci = 0.95)
abline(v=(90), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/GBP - left tail", "u = 1.7"))

hillPlot(x = y6,ci = 0.95)
abline(v=(85), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/JPY - left tail", "u = 2"))

hillPlot(x = y7,ci = 0.95)
abline(v=(120), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/TRY - left tail", "u = 1.3"))

hillPlot(x = y8,ci = 0.95)
abline(v=(100), col="red", lty=3, lwd=0.5)
legend("topright",c("EUR/USD - left tail", "u = 1.8"))


#next we study the length size k of the exceedances and adjust threshold u accordingly
#when gamma(extreme index) from hill estimator becomes stable.

Y1 = y1[order(y1,decreasing = T)]
Y2 = y2[order(y2,decreasing = T)]
Y3 = y3[order(y3,decreasing = T)]
Y4 = y4[order(y4,decreasing = T)]
Y5 = y5[order(y5,decreasing = T)]
Y6 = y6[order(y6,decreasing = T)]
Y7 = y7[order(y7,decreasing = T)]
Y8 = y8[order(y8,decreasing = T)] #order the excesses

#using hill estimator for the graphs of extr index gamma against k:
#choosing k:
par(mfrow = c(1,1))
gamma1 = matrix(0,1,k1)
M1 = matrix(0,1,k1)
gammaM1 = matrix(0,1,k1)
for (k in 1:k1){
  gamma1[k] = (sum(log(Y1[1:k]/Y1[k]))/k)^(-1)
  M1[k] = (sum(log(Y1[1:k]/Y1[k]))^2)/k
  gammaM1[k] = gamma1[k] + 1 - (1/2) * (1 - ((gamma1[k]^2)/M1[k]))
}
plot((2:k1),gamma1[2:k1],type = "l")
lines(gammaM1[2:k1],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##2

gamma2 = matrix(0,1,k2)
M2 = matrix(0,1,k2)
gammaM2 = matrix(0,1,k2)
for (k in 1:k2){
  gamma2[k] = (sum(log(Y2[1:k]/Y2[k]))/k)^(-1)
  M2[k] = (sum(log(Y2[1:k]/Y2[k]))^2)/k
  gammaM2[k] = gamma2[k] + 1 - (1/2) * (1 - ((gamma2[k]^2)/M2[k]))
}
plot((1:k2),gamma2,type = "l")
lines(gammaM2[2:k2],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##3

gamma3 = matrix(0,1,k3)
M3 = matrix(0,1,k3)
gammaM3 = matrix(0,1,k3)
for (k in 1:k3){
  gamma3[k] = (sum(log(Y3[1:k]/Y3[k]))/k)^(-1)
  M3[k] = (sum(log(Y3[1:k]/Y3[k]))^2)/k
  gammaM3[k] = gamma3[k] + 1 - (1/2) * (1 - ((gamma3[k]^2)/M3[k]))^(-1)
}
plot((1:k3),gamma3,type = "l")
lines(gammaM3[2:k3],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##4
gamma4 = matrix(0,1,k4)
M4 = matrix(0,1,k4)
gammaM4 = matrix(0,1,k4)
for (k in 1:k4){
  gamma4[k] = (sum(log(Y4[1:k]/Y4[k]))/k)^(-1)
  M4[k] = (sum(log(Y4[1:k]/Y4[k]))^2)/k
  gammaM4[k] = gamma4[k] + 1 - (1/2) * (1 - ((gamma4[k]^2)/M4[k]))^(-1)
}
plot((1:k4),gamma4,type = "l")
lines(gammaM4[2:k4],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##5

gamma5 = matrix(0,1,k5)
M5 = matrix(0,1,k5)
gammaM5 = matrix(0,1,k5)
for (k in 1:k5){
  gamma5[k] = (sum(log(Y5[1:k]/Y5[k]))/k)^(-1)
  M5[k] = (sum(log(Y5[1:k]/Y5[k]))^2)/k
  gammaM5[k] = gamma5[k] + 1 - (1/2) * (1 - ((gamma5[k]^2)/M5[k]))^(-1)
}
plot((2:k5),gamma5[2:k5],type = "l")
lines(gammaM5[2:k5],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##6
gamma6 = matrix(0,1,k6)
M6 = matrix(0,1,k6)
gammaM6 = matrix(0,1,k6)
for (k in 1:k6){
  gamma6[k] = (sum(log(Y6[1:k]/Y6[k]))/k)^(-1)
  M6[k] = (sum(log(Y6[1:k]/Y6[k]))^2)/k
  gammaM6[k] = gamma6[k] + 1 - (1/2) * (1 - ((gamma6[k]^2)/M6[k]))^(-1)
}
plot((1:k6),gamma6,type = "l")
lines(gammaM6[2:k6],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##7
gamma7 = matrix(0,1,k7)
M7 = matrix(0,1,k7)
gammaM7 = matrix(0,1,k7)
for (k in 1:k7){
  gamma7[k] = (sum(log(Y7[1:k]/Y7[k]))/k)^(-1)
  M7[k] = (sum(log(Y7[1:k]/Y7[k]))^2)/k
  gammaM7[k] = gamma7[k] + 1 - (1/2) * (1 - ((gamma7[k]^2)/M7[k]))^(-1)
}
plot((1:k7),gamma7,type = "l")
lines(gammaM7[2:k7],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

##8
gamma8 = matrix(0,1,k8)
M8 = matrix(0,1,k8)
gammaM8 = matrix(0,1,k8)
for (k in 1:k8){
  gamma8[k] = (sum(log(Y8[1:k]/Y8[k]))/k)^(-1)
  M8[k] = (sum(log(Y8[1:k]/Y8[k]))^2)/k
  gammaM8[k] = gamma8[k] + 1 - (1/2) * (1 - ((gamma8[k]^2)/M8[k]))^(-1)
}
plot((1:k8),gamma8,type = "l")
lines(gammaM8[2:k8],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")

###################################### fitting y excesses to GPD through MLE ##################################3333
#EUR/GBP positive
theta_ini = c(sd(y1),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y1)
results

sigma1 = results$estimate[1]
ksi1 = results$estimate[2]

#EUR/JPY pos
theta_ini = c(sd(y2),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y2)
results

sigma2 = results$estimate[1]
ksi2 = results$estimate[2]

#EUR/TRY pos
theta_ini = c(sd(y3),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y3)
results

sigma3 = results$estimate[1]
ksi3 = results$estimate[2]

#EUR/USD pos:
theta_ini = c(sd(y4),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y4)
results

sigma4 = results$estimate[1]
ksi4 = results$estimate[2]

#EUR/GBP neg:
theta_ini = c(sd(y5),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y5)
results

sigma5 = results$estimate[1]
ksi5 = results$estimate[2]

#EUR/JPY neg:
theta_ini = c(sd(y6),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y6)
results

sigma6 = results$estimate[1]
ksi6 = results$estimate[2]

#EUR/TRY neg
theta_ini = c(sd(y7),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y7)
results

sigma7 = results$estimate[1]
ksi7 = results$estimate[2]

#EUR/USD neg
theta_ini = c(sd(y8),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = y8)
results

sigma8 = results$estimate[1]
ksi8 = results$estimate[2]

#organising results:
sigmas = c(sigma1,sigma2, sigma3, sigma4, sigma5, sigma6, sigma7, sigma8)
ksis = c(ksi1, ksi2, ksi3, ksi4, ksi5, ksi6, ksi7, ksi8)
ksis
########### COMPARISON OF TAIL INDEX RESULTS WITH UNCONDITIONAL APPROACH #########
#results of tail index xi for uncond evt:
ksisUncon = c(0.30894314, 0.24771763, 0.20050524, 0.59437239, 0.06182258,
 0.13767051, 0.09460880, 0.50720116)
ksisUncon

#calc % difference with current conditional EVT estimates
pctgdiffright = (mean(ksis[1:4]) - mean(ksisUncon[1:4]))/mean(ksis[1:4])
pctgdiffright*100 # -0.1242% so Condit evt reduces tail index for right tail by that much

#calc % difference with current conditional EVT estimates
pctgdiffleft = (mean(ksis[5:8]) - mean(ksisUncon[5:8]))/mean(ksis[5:8])
pctgdiffleft*100 # -5.5% so Condit evt reduces tail index for left tail by that much

#################################### Hill estimator ##########################################
ksih = matrix(0,1,8)

#hill estimator for ksi:
ksih[1] = (sum(log(Y1/Y1[k1]))/k1)^(-1); ksih[1]; ksis[1]

ksih[2] = (sum(log(Y2/Y2[k2]))/k2)^(-1); ksih[2]; ksis[2]

ksih[3] = (sum(log(Y3/Y3[k3]))/k3)^(-1); ksih[3]; ksis[3]

ksih[4] = (sum(log(Y4/Y4[k4]))/k4)^(-1); ksih[4]; ksis[4]

ksih[5] = (sum(log(Y5/Y5[k5]))/k5)^(-1); ksih[5]; ksis[5]

ksih[6] = (sum(log(Y6/Y6[k6]))/k6)^(-1); ksih[6]; ksis[6]

ksih[7] = (sum(log(Y7/Y7[k7]))/k7)^(-1); ksih[7]; ksis[7]

ksih[8] = (sum(log(Y8/Y8[k8]))/k8)^(-1); ksih[8]; ksis[8]

################## Moment estimator #############################
par(mfrow = c(2,2))

Mq=function(sortx,k,q){    #computing block for the moment estimator, cf. formula (3.5.2) in  deHaan & Ferreira (2006)
  X=sort(sortx,decreasing=TRUE);
  result=numeric(length(k));
  for(i in 1:length(k)){
    Xdiff=(log(X[1:k[i]])-log(X[k[i]+1]))^q;
    result[i]=mean(Xdiff);
  }
  return(result);
}


g_mom=function(sortx,k)
{
  X=sort(sortx,decreasing=TRUE);
  result=numeric(length(k));
  M1=Mq(sortx,k,1);
  M2=Mq(sortx,k,2);  
  result=M1+1-0.5*M2/(M2-M1^2);
  return(result);
}

#simulation example
df=3;
xt=rt(5000,df);
k=10:1000;
gamma_mom= g_mom(xt,k)
gamma_mom
plot(gamma_mom, type ="l")

#
ksiM = matrix(0,1,8)

M1 = g_mom(y1,1:k1); M1 ; plot(M1[2:272], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/GBP right tail")
abline(0.25,0,col = "blue") #ksim1 = 0.4
ksiM[1] = mean(M1[94:270]) ; ksiM[1]
ksis[1]

#moment function to make sure results are the same 
M1i = Moment(data = y1)
M1i
plot(M1i$gamma[2:251], type = "l")

M2 = g_mom(y2,1:k2); M2; plot(M2[6:191], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/JPY right tail")
abline(0.4,0,col = "blue") #ksim2 = 0.25
ksiM[2] = mean(M2[84:131]) ; ksiM[2]
ksis[2]

M3 = g_mom(y3,1:k3); M3; plot(M3[3:270], type = "l", xlab = "k", ylab = "Moment Estimator",
                               main = "EUR/TRY right tail")
abline(0.30,0,col = "blue") #ksim3 = 0.55
ksiM[3] = mean(M3[11:251]) ; ksiM[3]
ksis[3]

M4 = g_mom(y4,1:k4); M4; plot(M4[3:267], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/USD right tail")
abline(0.55,0,col = "blue") #ksim4 = 0.6
ksiM[4] = mean(M4[14:42]) ; ksiM[4]
ksis[4]

M5 = g_mom(y5,1:k5); M5; plot(M5[2:324], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/GBP left tail")
abline(0.05,0,col = "blue") #ksim5 = 0.2
ksiM[5] = mean(M5[130:270]) ; ksiM[5]
ksis[5]

M6 = g_mom(y6,1:k6); M6  ; plot(M6[4:202], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/JPY left tail")
abline(0.43,0,col = "blue") #ksim6 = 0.2
ksiM[6] = mean(M6[50:70]) ; ksiM[6]
ksis[6]

M7 = g_mom(y7,1:k7); M7; plot(M7[3:369], type = "l", xlab = "k", ylab = "Moment Estimator", 
                               main = "EUR/TRY left tail")
abline(0.15,0,col = "blue") #ksim7 = 0.3
ksiM[7] = mean(M7[53:105]) ; ksiM[7]
ksis[7]


M8 = g_mom(y8,1:k8); M8; plot(M8[2:197], type = "l", xlab = "k", ylab = "Moment Estimator", main = "EUR/USD left tail")
abline(0.45,0,col = "blue") #ksim8 = 0.7
ksiM[8] = mean(M8[34:61]) ; ksiM[8]
ksis[8]

ksiM
#we choose the first stable area!!

M = matrix(0,1,8)
ksim = matrix(0,1,8)

#
M[1] = (sum(log(Y1/Y1[k1]))^2)/k1; ksim[1] = ksih[1] + 1 - (1/2) * (1 - ((ksih[1]^2)/M[1]))^(-1); ksim[1]

M[2] = (sum(log(Y2/Y2[k2]))^2)/k2; ksim[2] = ksih[2] + 1 - (1/2) * (1 - ((ksih[2]^2)/M[2]))^(-1); ksim[2]

M[3] = (sum(log(Y3/Y3[k3]))^2)/k3; ksim[3] = ksih[3] + 1 - (1/2) * (1 - ((ksih[3]^2)/M[3]))^(-1); ksim[3]

M[4] = (sum(log(Y4/Y4[k4]))^2)/k4; ksim[4] = ksih[4] + 1 - (1/2) * (1 - ((ksih[4]^2)/M[4]))^(-1); ksim[4]

M[5] = (sum(log(Y5/Y5[k5]))^2)/k5; ksim[5] = ksih[5] + 1 - (1/2) * (1 - ((ksih[5]^2)/M[5]))^(-1); ksim[5]

M[6] = (sum(log(Y6/Y6[k6]))^2)/k6; ksim[6] = ksih[6] + 1 - (1/2) * (1 - ((ksih[6]^2)/M[6]))^(-1); ksim[6]

M[7] = (sum(log(Y7/Y7[k7]))^2)/k7; ksim[7] = ksih[7] + 1 - (1/2) * (1 - ((ksih[7]^2)/M[7]))^(-1); ksim[7]

M[8] = (sum(log(Y8/Y8[k8]))^2)/k8; ksim[8] = ksih[8] + 1 - (1/2) * (1 - ((ksih[8]^2)/M[8]))^(-1); ksim[8]


#####prob plot:

y1 = y1[order(y1)]; y2 = y2[order(y2)]; y3 = y3[order(y3)]; y4 = y4[order(y4)] 
y5 = y5[order(y5)]; y6 = y6[order(y6)]; y7 = y7[order(y7)]; y8 = y8[order(y8)] 

#estimation of model:

H1 = 1 - (1 + (ksis[1]*y1)/sigmas[1])^(-1/ksis[1]); H2 = 1 - (1 + (ksis[2]*y2)/sigmas[2])^(-1/ksis[2])
H3 = 1 - (1 + (ksis[3]*y3)/sigmas[3])^(-1/ksis[3]); H4 = 1 - (1 + (ksis[4]*y4)/sigmas[4])^(-1/ksis[4])
H5 = 1 - (1 + (ksis[5]*y5)/sigmas[5])^(-1/ksis[5]); H6 = 1 - (1 + (ksis[6]*y6)/sigmas[6])^(-1/ksis[6])
H7 = 1 - (1 + (ksis[7]*y7)/sigmas[7])^(-1/ksis[7]); H8 = 1 - (1 + (ksis[8]*y8)/sigmas[8])^(-1/ksis[8])

#plots:
par(mfrow = c(2,2))

#EUR/GBP pos:
i1 = seq(1,k1,1)
empirical1 = i1/(k1+1)
plot(x = empirical1,y = H1, main = "Probability Plot: EUR/GBP - right tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1,lwd = 2)

#EUR/JPY pos:
i2 = seq(1,k2,1)
empirical2 = i2/(k2+1)
plot(x = empirical2,y = H2, main = "Probability Plot: EUR/JPY - right tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1, lwd = 2)

#EUR/TRY pos:
i3 = seq(1,k3,1)
empirical3 = i3/(k3+1)
plot(x = empirical3,y = H3, main = "Probability Plot: EUR/TRY - right tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1, lwd = 2)

#EUR/USD pos:
i4 = seq(1,k4,1)
empirical4 = i4/(k4+1)
plot(x = empirical4,y = H4, main = "Probability Plot: EUR/USD - right tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1, lwd = 2)

#EUR/GBP neg :
i5 = seq(1,k5,1)
empirical5 = i5/(k5+1)
plot(x = empirical5,y = H5, main = "Probability Plot: EUR/GBP - left tail",
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1, lwd = 2)

#EUR/JPY neg :
i6 = seq(1,k6,1)
empirical6 = i6/(k6+1)
plot(x = empirical6,y = H6, main = "Probability Plot: EUR/JPY - left tail",
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1, lwd = 2)

#EUR/TRY neg :
i7 = seq(1,k7,1)
empirical7 = i7/(k7+1)
plot(x = empirical7,y = H7, main = "Probability Plot: EUR/TRY - left tail", 
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1, lwd = 2)

#EUR/USD neg :
i8 = seq(1,k8,1)
empirical8 = i8/(k8+1)
plot(x = empirical8,y = H8, main = "Probability Plot: EUR/USD - left tail",
     ylab = "Model",xlab = "Empirical", frame.plot = F, col = "red")
abline(0,1, lwd = 2)

#quantile plot:
#use of decreasing order
par(mfrow = c(2,2))
#EUR/GBP pos
Y1
h1 = u[1] + (sigmas[1]/ksis[1]) * (empirical1^(-ksis[1])-1)
plot(h1~Y1, main = "Quantile Plot: EUR/GBP - right tail", ylab = "Empirical", 
     xlab = "Model", frame.plot = F, col = "blue")
quantplot1 = lm(h1~Y1)
abline(quantplot1, lwd = 2)


#EUR/JPY pos
h2 = u[2] + (sigmas[2]/ksis[2]) * (empirical2^(-ksis[2])-1)
plot(h2~Y2, main = "Quantile Plot: EUR/JPY - right tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot2 = lm(h2~Y2)
abline(quantplot2, lwd = 2)

#EUR/TRY pos
h3 = u[3] + (sigmas[3]/ksis[3]) * (empirical3^(-ksis[3])-1)
plot(h3~Y3, main = "Quantile Plot: EUR/TRY - right tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot3 = lm(h3~Y3)
abline(quantplot3, lwd = 2)

#EUR/USD pos
h4 = u[4] + (sigmas[4]/ksis[4]) * (empirical4^(-ksis[4])-1)
plot(h4~Y4, main = "Quantile Plot: EUR/USD - right tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot4 = lm(h4~Y4)
abline(quantplot4, lwd = 2)

#EUR/GBP neg:
h5 = u[5] + (sigmas[5]/ksis[5]) * (empirical5^(-ksis[5])-1)
plot(h5~Y5, main = "Quantile Plot: EUR/GBP - left tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot5 = lm(h5~Y5)
abline(quantplot5, lwd = 2)

#EUR/JPY neg:
h6 = u[6] + (sigmas[6]/ksis[6]) * (empirical6^(-ksis[6])-1)
plot(h6~Y6, main = "Quantile Plot: EUR/JPY - left tail", ylab = "Empirical", 
     xlab = "Model", frame.plot = F, col = "blue")
quantplot6 = lm(h6~Y6)
abline(quantplot6, lwd =2)

#EUR/TRY neg:
h7 = u[7] + (sigmas[7]/ksis[7]) * (empirical7^(-ksis[7])-1)
plot(h7~Y7, main = "Quantile Plot: EUR/TRY - left tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot7 = lm(h7~Y7)
abline(quantplot7, lwd = 2)

#EUR/USD neg:
h8 = u[8] + (sigmas[8]/ksis[8]) * (empirical8^(-ksis[8])-1)
plot(h8~Y8, main = "Quantile Plot: EUR/USD - left tail", ylab = "Empirical",
     xlab = "Model", frame.plot = F, col = "blue")
quantplot8 = lm(h8~Y8)
abline(quantplot8, lwd = 2)

######################## density plot ########################################
par(mfrow = c(2,2))

hist(y1, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y1), max(y1), length.out = 20),
     main = "Histogram: EUR/GBP - right tail")
lines(y1,dgpd(y1,xi = ksis[1]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()

hist(y2, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y2), max(y2), length.out = 20),
     main = "Histogram: EUR/JPY - right tail")
lines(y2,dgpd(y2,xi = ksis[2]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()


hist(y3, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y3), max(y3), length.out = 20),
     main = "Histogram: EUR/TRY - right tail")
lines(y3,dgpd(y3,xi = ksis[3]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()

hist(y4, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y4), max(y4), length.out = 20),
     main = "Histogram: EUR/USD - right tail")
lines(y4,dgpd(y4,xi = ksis[4]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()

hist(y5, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y5), max(y5), length.out = 20),
     main = "Histogram: EUR/GBP - left tail")
lines(y5,dgpd(y5,xi = ksis[5]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()


hist(y6, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y6), max(y6), length.out = 20),
     main = "Histogram: EUR/JPY - left tail")
lines(y6,dgpd(y6,xi = ksis[6]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()


hist(y7, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y7), max(y7), length.out = 20),
     main = "Histogram: EUR/TRY - left tail")
lines(y7,dgpd(y7,xi = ksis[7]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()


hist(y8, col="cyan",border="white",prob = TRUE, xlab = "y", ylab = "H(y)",
     breaks =  seq(min(y8), max(y8), length.out = 20),
     main = "Histogram: EUR/USD - left tail")
lines(y8,dgpd(y8,xi = ksis[8]),lwd = 2,lty = 1,col = "navy")
legend("topright",legend = "GPD model Density",lty = 1,lwd = 2,col = "navy")
box()


################################# VaR CALCULATION #####################

#vector of VaR probabilities
p =c(0.05,0.025,0.01,0.005,0.001)
Value.at.risk = matrix(0,5,8)
K = c(k1,k2,k3,k4,k5,k6,k7,k8)

#VaR for pos and neg returns
for (i in 1:8){
  for (t in 1:5){
    Value.at.risk[t,i] = u[i] + (sigmas[i]/ksis[i]) * (((p[t])*(length(garchresid[,2])/K[i]))^(-ksis[i]) - 1) 
  }
}  
Value.at.risk
#create profile likelihood for confidence interval of VaR.

#EXPECTED SHORTFALL CALCULATION:

ES = matrix(0,5,8)
for (i in 1:8){
  for (t in 1:5){
    ES[t,i] = (Value.at.risk[t,i]/(1 - ksis[i])) + ((sigmas[i] - ksis[i] * u[i])/(1 - ksis[i])) 
  }
}
ES


########################### Data simulation to check results ######################
#data simulation
data = rt(n = 4187,df = 3,)

#threshold creation
ud = seq(0,max(data),0.1)
xd = vector('numeric',length(ud))

for (i in 1:length(xd)){
  threshold.exceedancesd = data[data>ud[i]]
  xd[i] = mean(threshold.exceedancesd-ud[i])
}

#mean resid life plot for threshold selection
par(mfrow = c(1,1))
plot(xd~ud,type = "l",main = "i) Mean Residual Life Plot: Simulated Data", ylab = "mean excess",xaxt = "none")
axis(1, seq(0,20,1))
#ud = 2.1

ud=1.5

#creating excesses and length kd
exceedancesd = data[data>ud]; yd = exceedancesd - ud; kd = length(yd)

#decreasing ordering
Yd = yd[order(yd,decreasing = T)]

#hill estimator to different k's
par(mfrow = c(1,1))
gammad = matrix(0,1,kd)
Md = matrix(0,1,kd)
gammaMd = matrix(0,1,kd)
for (k in 1:kd){
  gammad[k] = (sum(log(Yd[1:k]/Y1[k]))/k)^(-1)
  Md[k] = (sum(log(Yd[1:k]/Yd[k]))^2)/k
  gammaMd[k] = gammad[k] + 1 - (1/2) * (1 - ((gammad[k]^2)/Md[k]))
}
plot((1:kd),gammad[1:kd],type = "l" )
lines(gammaMd[1:kd],type = "l", col = "red")
legend("topright", c("hill estimator","moment estimator"),fill=c("black","red"))
abline(1,0,col = "blue")
#stable around 0.56

#fitting y excesses to GPD through MLE:
theta_ini = c(sd(yd),0.1)

source("llik_GPD.R")
options(scipen=999)

#maximization through Newton-Raphson algorithm
results = nlm(f = llik_GPD,p = c(theta_ini),y = yd)
results

sigmad = results$estimate[1]
ksid = results$estimate[2]

#hill estimator:
ksihd = (sum(log(Yd/Yd[kd]))/kd)^(-1)
ksihd

#moment estimator
Md = (sum(log(Yd/Yd[kd]))^2)/kd
ksimd = ksihd + 1 - (1/2) * (1 - ((ksihd^2)/Md))^(-1)
ksimd

zd = kd/length(data)

#value at risk:
VaRd = matrix(0,5,1)
for (t in 1:5){
  VaRd[t] = ud + (sigmad/ksid) * (((p[t])*(length(data)/kd))^(-ksid) - 1) 
}
VaRd

ESd = matrix(0,5,1)
for (t in 1:5){
  ESd[t] = (VaRd[t]/(1 - ksid)) + ((sigmad - ksid * ud)/(1 - ksid)) 
}

ESd





