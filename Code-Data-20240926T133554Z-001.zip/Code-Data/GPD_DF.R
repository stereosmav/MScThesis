GPD.DF = function(emp,sigma_hat,ksi){
  if (ksi == 0){
    GPD = 1 - exp(-(y/sigma_hat))
  }
  else{
    GPD =  1 - (1 + (ksi * y)/sigma_hat)^(-1/ksi)
  }
  return(GPD)
}